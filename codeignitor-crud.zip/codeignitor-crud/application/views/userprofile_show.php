<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2> Show Profile</h2>
        </div>
        <div class="pull-right">
            <a class="btn btn-primary" href="<?php echo site_url('users'); ?>"> Back</a>
        </div>
    </div>
</div>

<div class="row">

    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>User Name:</strong>
	        <?php echo $users['user_name']; ?>
        </div>
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>User Email:</strong>
	        <?php echo $users['user_email']; ?>
        </div>
    </div>


    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>User Mobile:</strong>
	        <?php echo $users['user_mobile']; ?>
        </div>
    </div>

</div>


