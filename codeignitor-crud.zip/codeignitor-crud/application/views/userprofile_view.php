<div class="row">
	<div class="col-lg-12 margin-tb">
		<div class="pull-left">
			<h2>CRUD Operation</h2>
		</div>
		<div class="pull-right">
			<a class="btn btn-success" href="<?php echo site_url('users/add_form'); ?>"> Add New User</a>
		</div>
	</div>
</div>



<?php 
if($this->session->flashdata('msg')){
?>

<div class="alert alert-success">
	<p>
<?php echo $this->session->flashdata('msg');
?>
 </p>
</div>

<?php
}
?>  

<?php
$i=0;
?>
<table class="table table-bordered">
	<tr>
		<th>No</th>
		<th>Name</th>
		<th>Email</th>
		<th>Mobile</th>
		<th >Action</th>
	</tr>
      <?php foreach ($users as $user): ?>
        <tr>
		<td><?php echo  ++$i ?></td>

            <td><?php echo $user->user_name; ?></td>
            <td><?php echo $user->user_mobile; ?></td>
            <td><?php echo $user->user_email; ?></td>
            
			<td>
                <a  class="btn btn-info" href="<?php echo site_url('user/'.$user->user_id); ?>">View</a> 
                <a  class="btn btn-primary" href="<?php echo site_url('users/edit/'.$user->user_id); ?>">Edit</a>  
                <a  class="btn btn-danger" href="<?php echo site_url('users/delete/'.$user->user_id); ?>" onClick="return confirm('Are you sure you want to delete?')">Delete</a>
            </td>
        </tr>
<?php endforeach; ?>
    </tbody>
  </table>
  
  
  
<div >
<ul class="pagination">

<!-- Show pagination links -->
<?php foreach ($links as $link) {
echo "<li>". $link."</li>";
} ?>
</div>