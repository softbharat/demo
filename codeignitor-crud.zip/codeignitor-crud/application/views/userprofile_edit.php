    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Edit User</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-primary" href="<?php echo site_url('users'); ?>"> Back</a>
            </div>
        </div>
    </div>

 <form name="create" action="<?php echo site_url('users/edit/'.$user_list['user_id']); ?>" method="post" id="update" >
        <div class="row">
<div class="col-lg-6">
    <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12 ">
                <div class="form-group">
                    <strong>User Name:</strong>
<?php
                    if(set_value('user_name') != '')
                            $user_list['user_name']  = set_value('user_name');
                        elseif($user_list['user_name'] != '')
                            $user_list['user_name']  = $user_list['user_name'] ;
                       
                    else
                       
                            $user_list['user_name']  = '' ;
                       
                    
?>     
	 <input type="text" name="user_name" id="user_name" placeholder="User Name" class="form-control" value="<?php echo $user_list['user_name'];?>">
                </div>
				<?php echo form_error('user_name','<div class="alert alert-danger">','</div>'); ?>
	
            </div>

            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Email:</strong>

<?php
                    if(set_value('user_email') != '')
                            $user_list['user_email']   = set_value('user_email');
                        elseif($user_list['user_name'] != '')
                            $user_list['user_email']  = $user_list['user_email'] ;
                       
                    else
                       
                            $user_list['user_email']  = '' ;
                       
                    
?> 

                    <input type="text" name="user_email" id="user_email" placeholder="User Email" class="form-control" value="<?php echo $user_list['user_email'];?>">
                </div>
            <?php echo form_error('user_email','<div class="alert alert-danger">','</div>'); ?>
	
			</div>

            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Mobile:</strong>
  
<?php
                    if(set_value('user_mobile') != '')
                            $user_list['user_mobile']   = set_value('user_mobile');
                        elseif($user_list['user_mobile'] != '')
                            $user_list['user_mobile']  = $user_list['user_mobile'] ;
                       
                    else
                       
                            $user_list['user_mobile']  = '' ;
                       
                    
?>                    <input type="text" name="user_mobile" id="user_mobile" placeholder="User Mobile" class="form-control" value="<?php echo $user_list['user_mobile'];?>">
                </div>
<?php echo form_error('user_mobile','<div class="alert alert-danger">','</div>'); ?>
	    
	</div>

            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Country:</strong>

					<?php
                    if(set_value('user_country') != '')
                            $user_list['user_country']   = set_value('user_country');
                        elseif($user_list['user_country'] != '')
                            $user_list['user_country']  = $user_list['user_country'] ;
                       
                    else
                       
                            $user_list['user_country']  = '' ;
                       
                    
?> 
                    <?php
                        $select_india = '';
                        $select_usa = '';
                        $select_uk = '';
                    
                    if($user_list['user_country'] == 'India')
                            $select_india = 'selected="selected"';
                    elseif($user_list['user_country'] == 'USA')
                            $select_usa = 'selected="selected"';
                    elseif($user_list['user_country'] == 'UK')
                            $select_uk = 'selected="selected"';
                    
					?>
                    <select class="form-control" id="user_country" name="user_country">
                        <option value="">Select</option>
                        <option value="India" <?php echo $select_india ;?>>India</option>
                        <option value="USA" <?php echo $select_usa ;?>>USA</option>
                        <option value="UK" <?php echo $select_uk ;?>>UK</option>
                    </select>

                </div>
				<?php echo form_error('user_country','<div class="alert alert-danger">','</div>'); ?>
	
            </div>


            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Register Date:</strong>
					
					<?php
                    if(set_value('user_date') != '')
                            $user_list['user_date']   = set_value('user_date');
                         
                    else
                       
                            $user_list['user_date']  = '' ;
                       
                    
?> 
   
                    <input class="form-control datepicker" id="id_reg" name="user_date" value="<?php echo $user_list['user_date'];?>">



                </div>
				<?php echo form_error('user_date','<div class="alert alert-danger">','</div>'); ?>
	
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
				<?php
                    if(set_value('user_gender') != '')
                            $user_list['user_gender']   = set_value('user_gender');
                        elseif($user_list['user_gender'] != '')
                            $user_list['user_gender']  = $user_list['user_gender'] ;
                       
                    else
                       
                            $user_list['user_gender']  = '' ;
                       
                    
    
                        $select_male = '';
                        $select_female = '';

                    if($user_list['user_gender'] == 'Male')
                            $select_male = 'checked="checked"';
                    elseif($user_list['user_gender'] == 'Female')
                            $select_female = 'checked="checked"';
                    ?>
                    <strong>Gender:</strong>
                    <div class="form-control" style="border: 0px;">

                        <input type="radio" name="user_gender" id="user_gender" value="Male" <?php echo $select_male;?>> Male

                        &nbsp;&nbsp;
                        <input type="radio" name="user_gender" id="user_gender" value="Female" <?php echo $select_female;?> > FeMale
                    </div>
                </div>
            </div>


            <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                <button type="submit" class="btn btn-primary">Update</button>
            </div>

        </div>
</div>
        </div>
    </form>

    <script>
        $(document).ready(function() {
            $('.datepicker').datepicker();

            $.validator.addMethod("valid_date", function(value, element) {
                var flag = false;
                var date = value;
                arr_date = date.split('/');
                var day =arr_date[1];
                var mon =arr_date[0];
                var year =arr_date[2];

                if(day<1 || day >31){
                    return false;
                }
                if(mon<1 || mon >12){
                    return false;
                }
                if(year<2010){
                    return false;
                }
                return true;
            }, "");
            // validate signup form on keyup and submit
            $("#update").validate({
                rules: {
                    user_name: {
                        required: true,
                        minlength: 2
                    },
                    user_country: {
                        required: true

                    },
                    user_date: {
                        required: true,
                        valid_date : true
                    },
                    user_email: {
                        required: true,
                        email: true
                    },
                    user_mobile: {
                        required: true,
                        minlength: 10,
                        number:true
                    },

                },
                messages: {

                    user_mobile: "Please enter mobile",
                    user_email: {
                        required: "Please enter email",
                        email: "Enter valid email"
                    },
                    user_name: {
                        required: "Please enter your name",
                        minlength: "Your name must be at least 2 characters long"
                    },
                    user_country: "Please select country",
                    user_date:{
                        required:"Please select date",
                        valid_date :'Please select valid date'
                    }

                }
            });
        });
    </script>










