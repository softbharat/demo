<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2>Add New User</h2>
        </div>
        <div class="pull-right">
            <a class="btn btn-primary" href="<?php echo site_url('users'); ?>"> Back</a>
        </div>
    </div>
</div>


<form  name="create" action="<?php echo site_url('users/add_form'); ?>" id="create" method="post">
   

    <div class="row">
        <div class="col-lg-6">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>User Name:</strong>
                        <input type="text" name="user_name" id="user_name" placeholder="User Name" class="form-control" value="<?php echo set_value('user_name');?>">
  <?php echo form_error('user_name','<div class="alert alert-danger">','</div>'); ?>
				
                    
</div>                </div>

                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>Email:</strong>
                        <input type="text" name="user_email" id="user_email" placeholder="User Email" class="form-control" value="<?php echo set_value('user_email'); ?>">
<?php echo form_error('user_email','<div class="alert alert-danger">','</div'); ?>

						</div>
                </div>

                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>Mobile:</strong>
                        <input type="text" name="user_mobile" id="user_mobile" placeholder="User Mobile" class="form-control"  value="<?php echo set_value('user_mobile'); ?>">
<?php echo form_error('user_mobile','<div class="alert alert-danger">','</div'); ?>

                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>Country:</strong>
                        <?php
                       
                        $select_india = '';
                        $select_usa = '';
                        $select_uk = '';
                        
                        if(set_value('user_country') == 'India')
                        $select_india = 'selected="selected"';
                       
                        elseif(set_value('user_country') == 'USA')
                        $select_usa = 'selected="selected"';
                        
                        elseif(set_value('user_country') == 'UK')
                        $select_uk = 'selected="selected"';
                       
                        
                        ?>
                        <select class="form-control" id="user_country" name="user_country">
                            <option value="">Select</option>
                            <option value="India" <?php echo $select_india; ?>>India</option>
                            <option value="USA" <?php echo $select_usa ?>>USA</option>
                            <option value="UK" <?php echo $select_uk ?>>UK</option>
                        </select>
<?php echo form_error('user_country','<div class="alert alert-danger">','</div'); ?>

                    </div>
                </div>


                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>Register Date:</strong>

                        <input class="form-control datepicker" id="id_reg" name="user_date" value="<?php echo set_value('user_date'); ?>">

<?php echo form_error('user_date','<div class="alert alert-danger">','</div'); ?>


                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
	                    <?php
                        $select_male = '';
                        $select_female = '';

                        if(set_value('user_gender')== 'Male')
                        $select_male = 'checked="checked"';
                        
                        elseif(set_value('user_gender') == 'Female')
                        $select_female = 'checked="checked"';
                        ?>
                        <strong>Gender:</strong>
                        <div class="form-control" style="border: 0px;">

                            <input type="radio" name="user_gender" id="user_gender" value="Male" <?php echo $select_male ?>> Male

                            &nbsp;&nbsp;
                            <input type="radio" name="user_gender" id="user_gender" value="Female" <?php echo $select_female ?> > FeMale
                        </div>
<?php echo form_error('user_gender','<div class="alert alert-danger">','</div'); ?>

						</div>
                </div>



                <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                    <button type="submit" class="btn btn-primary" id="submit_form" name="submit_form">Submit</button>
                </div>

            </div>
        </div>
    </div>
</form>











<script>
    $(document).ready(function() {
        $('.datepicker').datepicker();

        $.validator.addMethod("valid_date", function(value, element) {
            var flag = false;
            var date = value;
            arr_date = date.split('/');
            var day =arr_date[1];
            var mon =arr_date[0];
            var year =arr_date[2];

            if(day<1 || day >31){
                return false;
            }
            if(mon<1 || mon >12){
                return false;
            }
            if(year<2010){
                return false;
            }
            return true;
        }, "");
        // validate signup form on keyup and submit
        $("#create").validate({
            rules: {
                user_name: {
                    required: true,
                    minlength: 2
                },
                user_country: {
                    required: true

                },
                user_date: {
                    required: true,
                    valid_date : true
                },
                user_email: {
                    required: true,
                    email: true
                },
                user_mobile: {
                    required: true,
                    minlength: 10,
                    number:true
                },

            },
            messages: {

                user_mobile: "Please enter mobile",
                user_email: {
                    required: "Please enter email",
                    email: "Enter valid email"
                },
                user_name: {
                    required: "Please enter your name",
                    minlength: "Your name must be at least 2 characters long"
                },
                user_country: "Please select country",
                user_date:{
                    required:"Please select date",
                    valid_date :'Please select valid date'
                }

            },
            errorPlacement:function(error, element) {
                error.insertAfter(element);
            },

            submitHandler: function(form) {

                form.submit();
            }

        });
    });
</script>