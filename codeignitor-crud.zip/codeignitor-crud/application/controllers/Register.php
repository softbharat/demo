<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Register extends CI_Controller {

	Public function __construct()
	{
		parent::__construct();
		$this->load->helper('url');
		$this->load->model('register_model');
        $this->load->helper('url_helper');
		//$this->session->keep_flashdata('msg');
	}
	
	 public function index()
    {
	
	
	$config = array();
	$config["base_url"] = base_url() . "/users/index";
	$total_row = $this->register_model->record_count();
	$config["total_rows"] = $total_row;
	$config["per_page"] = 5;
	$config['use_page_numbers'] = TRUE;
	$config['num_links'] = $total_row;
	$config['cur_tag_open'] = '&nbsp;<a class="current">';
	$config['cur_tag_close'] = '</a>';
	$config['next_link'] = 'Next';
	$config['prev_link'] = 'Previous';
	$this->load->library('pagination');

	$this->pagination->initialize($config);
	print_r($this->uri->segment(3));
	if($this->uri->segment(3)){
		$page = ($this->uri->segment(3)) ;
	}
	else{
	$page = 0;
	}

	$page = max(0, ( $page -1 ) * $config["per_page"]);

	$data["users"] = $this->register_model->fetch_data($config["per_page"], $page);
	$str_links = $this->pagination->create_links();
	$data["links"] = explode('&nbsp;',$str_links );


	
	
	
        //$data['users'] = $this->register_model->get_users();
        
        $this->load->view('templates/header');
        $this->load->view('userprofile_view', $data);
        $this->load->view('templates/footer');
		
    }
	
	public function create()
    {
	
        $this->load->library('form_validation');
		$this->form_validation->set_rules('user_email', 'Email', 'required|valid_email');
        $this->form_validation->set_rules('user_name', 'Name', 'required|min_length[10]');
		$this->form_validation->set_rules('user_mobile', 'mobile', 'required|max_length[10]|callback_valid_number');
		
		$this->form_validation->set_rules('user_country', 'Country', 'required');
		$this->form_validation->set_rules('user_date', 'Date', 'required');
		
		
		
		$data['error'] = '';
        if ($this->form_validation->run() === FALSE)
        {
            $this->load->view('templates/header');
            $this->load->view('userprofile_add',$data);
            $this->load->view('templates/footer');
 
        }
        else
        {
			
			
			$name = $this->input->post('user_name');
			$data['users'] = $this->register_model->get_users($name);
			if (!empty($data['users']))
			{
				$data['error']= 'User Already Exist!';
				$this->load->view('templates/header');
				$this->load->view('userprofile_add',$data);
				$this->load->view('templates/footer');
				return;
				
			}	
				
			$this->register_model->set_users();
			$data['users'] = $this->register_model->get_users();
			$this->session->set_flashdata('msg','Created Successfully!');
			redirect( base_url() . 'users','refresh');        
    
			
			}
    }
    
	function valid_number($mobile){
	$this->form_validation->set_message('valid_number', 'The mobile must be valid digit');


	 if (preg_match('/\d/', $mobile)){
	 return true;
	 }else {
	 return false;
	 }
	
	}	



 public function view($id = NULL)
    {
        $data['users'] = $this->register_model->get_user_by_id($id);
        
        if (empty($data['users']))
        {
            show_404();
        }
 
      
        $this->load->view('templates/header');
        $this->load->view('userprofile_show', $data);
        $this->load->view('templates/footer');
    }

	
	public function edit()
    {
        $id = $this->uri->segment(3);
        
        if (empty($id))
        {
            show_404();
        }
        
         
		 $this->load->library('form_validation');
        
        $data['user_list'] = $this->register_model->get_user_by_id($id);
        
    	$this->form_validation->set_rules('user_email', 'Email', 'required|valid_email');
        $this->form_validation->set_rules('user_name', 'Name', 'required|min_length[10]');
		$this->form_validation->set_rules('user_mobile', 'mobile', 'required|max_length[10]|callback_valid_number');
		
		$this->form_validation->set_rules('user_country', 'Country', 'required');
		$this->form_validation->set_rules('user_date', 'Date', 'required');
		
        if ($this->form_validation->run() === FALSE)
        {
            $this->load->view('templates/header');
            $this->load->view('userprofile_edit', $data);
            $this->load->view('templates/footer');
 
        }
        else
        {
		$this->session->set_flashdata('msg','Updated Successfully!');
            $this->register_model->set_users($id);
            redirect( base_url() . 'users','refresh');
        }
    }
	
	
	
	
	
	
	
	
	public function delete()
    {
        $id = $this->uri->segment(3);
        
        if (empty($id))
        {
            show_404();
        }
                
        $user = $this->register_model->get_user_by_id($id);
        if(!empty($user)){
        $this->register_model->delete_user($id); 
		$this->session->set_flashdata('msg','Deleted Successfully!');		
        }
		redirect( base_url() . 'users','refresh');        
    }


	
	
}
