<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Register_Model extends CI_Model {

	
	
	 public function __construct()
    {
        $this->load->database();
    }
    
    public function get_users($slug = FALSE)
    {
        if ($slug === FALSE)
        {
            $query = $this->db->get('flt_users');
            return $query->result_array();
        }
 
        $query = $this->db->get_where('flt_users', array('user_name' => $slug));
        return $query->row_array();
    }
    
	
	
	public function set_users($id = 0)
    {
        $data = array(
            'user_name' => $this->input->post('user_name'),
            'user_email' => $this->input->post('user_email'),
            'user_mobile' => $this->input->post('user_mobile'),
			'user_country' => $this->input->post('user_country'),
            'user_gender' => $this->input->post('user_gender')
        );
        
        if ($id == 0) {
            return $this->db->insert('flt_users', $data);
        } else {
            $this->db->where('user_id', $id);
            return $this->db->update('flt_users', $data);
        }
    }
    
	
	
    public function get_user_by_id($id = 0)
    {
        if ($id === 0)
        {
            $query = $this->db->get('flt_users');
            return $query->result_array();
        }
 
        $query = $this->db->get_where('flt_users', array('user_id' => $id));
        return $query->row_array();
    }
    
	public function delete_user($id)
    {
        $this->db->where('user_id', $id);
        return $this->db->delete('flt_users');
    }
	
	
	
	
	
	public function record_count() {
		return $this->db->count_all("flt_users");
	}

	// Fetch data according to per_page limit.
	public function fetch_data($limit, $id) {
		$this->db->limit($limit,$id);
		//$this->db->where('id', $id);
		$query = $this->db->get("flt_users");
		//print_r($query);


		if ($query->num_rows() > 0) {
		foreach ($query->result() as $row) {
		$data[] = $row;
		}
		return $data;
		}
	return false;
	}
	
	
	
}
