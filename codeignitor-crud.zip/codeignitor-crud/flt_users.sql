
CREATE TABLE `flt_users` (
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `user_name` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_email` varchar(255) COLLATE utf8_unicode_ci NOT NULL,
  `user_gender` varchar(10) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_mobile` varchar(50) COLLATE utf8_unicode_ci DEFAULT NULL,
  `user_country` varchar(30) COLLATE utf8_unicode_ci DEFAULT 'India'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `flt_users`
--

INSERT INTO `flt_users` (`user_id`, `user_name`, `user_email`, `user_gender`, `user_mobile`, `user_country`) VALUES
(2, 'MAIN USER TEST', 'bharattest@test.com', 'Male', '8798765678', 'India'),
(4, 'Bharatrawal8978333', 'es@test.com', 'Male', '9878909089', 'India'),
(6, 'Bharatrawal8978333876', 'es@test.com', 'Male', '9878909089', 'India'),
(7, 'bharattestrewrt', 'test@me.com', 'Male', '6785677789', 'USA'),
(8, 'martunjaytiwari', 'tr@te.com', 'Female', '7678778888', 'UK'),
(9, 'Bharatrawal897878', 'rewts@test.com', 'Male', '7657658797', 'USA'),
(10, 'rajasthantest', 'test@kak.com', 'Male', '6789898990', 'India');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `flt_users`
--
ALTER TABLE `flt_users`
  ADD PRIMARY KEY (`user_id`),
 
--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `flt_users`
--
ALTER TABLE `flt_users`
  MODIFY `user_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1;