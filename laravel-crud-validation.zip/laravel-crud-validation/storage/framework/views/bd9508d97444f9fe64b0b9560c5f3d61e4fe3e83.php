<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Add New User</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-primary" href="<?php echo e(route('userprofile.index')); ?>"> Back</a>
            </div>
        </div>
    </div>

    <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            There were some problems with your input.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form  name="create" action="<?php echo e(route('userprofile.store' )); ?>" id="create" method="post">
        <?php echo e(csrf_field()); ?>


    <div class="row">
        <div class="col-lg-6">
            <div class="row">
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>User Name:</strong>
                <input type="text" name="user_name" id="user_name" placeholder="User Name" class="form-control" value="<?php echo e(old('user_name')); ?>">

            </div>
        </div>

        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Email:</strong>
                <input type="text" name="user_email" id="user_email" placeholder="User Email" class="form-control" value="<?php echo e(old('user_email')); ?>">
            </div>
        </div>

        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Mobile:</strong>
                <input type="text" name="user_mobile" id="user_mobile" placeholder="User Mobile" class="form-control"  value="<?php echo e(old('user_mobile')); ?>">

            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Country:</strong>
                <?php 
                    $select_india = '';
                    $select_usa = '';
                    $select_uk = '';
                 ?>
                <?php if(old('user_country') == 'India'): ?>
                    <?php 
                        $select_india = 'selected="selected"';
                     ?>
                <?php elseif(old('user_country') == 'USA'): ?>
                    <?php 
                        $select_usa = 'selected="selected"';
                     ?>
                <?php elseif(old('user_country') == 'UK'): ?>
                    <?php 
                        $select_uk = 'selected="selected"';
                     ?>
                <?php endif; ?>
                <select class="form-control" id="user_country" name="user_country">
                    <option value="">Select</option>
                    <option value="India" <?php echo e($select_india); ?>>India</option>
                    <option value="USA" <?php echo e($select_usa); ?>>USA</option>
                    <option value="UK" <?php echo e($select_uk); ?>>UK</option>
                </select>

            </div>
        </div>


        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>Register Date:</strong>

                    <input class="form-control datepicker" id="id_reg" name="user_date" value="<?php echo e(old('user_date')); ?>">



            </div>
        </div>
        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <?php 
                    $select_male = '';
                    $select_female = '';

                 ?>
                <?php if(old('user_gender') == 'Male'): ?>
                    <?php 
                        $select_male = 'checked="checked"';
                     ?>
                <?php elseif(old('user_gender') == 'Female'): ?>
                    <?php 
                        $select_female = 'checked="checked"';
                     ?>
                <?php endif; ?>
                <strong>Gender:</strong>
                <div class="form-control" style="border: 0px;">

                <input type="radio" name="user_gender" id="user_gender" value="Male" <?php echo e($select_male); ?>> Male

                &nbsp;&nbsp;
                <input type="radio" name="user_gender" id="user_gender" value="Female" <?php echo e($select_female); ?> > FeMale
                </div>
            </div>
        </div>



        <div class="col-xs-12 col-sm-12 col-md-12 text-center">
            <button type="submit" class="btn btn-primary" id="submit_form">Submit</button>
        </div>

    </div>
        </div>
    </div>
    </form>

    <script>
        $(document).ready(function() {
            $('.datepicker').datepicker();

            $.validator.addMethod("valid_date", function(value, element) {
                var flag = false;
                var date = value;
                arr_date = date.split('/');
                var day =arr_date[1];
                var mon =arr_date[0];
                var year =arr_date[2];

                if(day<1 || day >31){
                    return false;
                }
                if(mon<1 || mon >12){
                    return false;
                }
                if(year<2010){
                    return false;
                }
                return true;
            }, "");
            // validate signup form on keyup and submit
            $("#create").validate({
                rules: {
                    user_name: {
                        required: true,
                        minlength: 2
                    },
                    user_country: {
                        required: true

                    },
                    user_date: {
                        required: true,
                        valid_date : true
                    },
                    user_email: {
                        required: true,
                        email: true
                    },
                    user_mobile: {
                        required: true,
                        minlength: 10,
                        number:true
                    },

                },
                messages: {

                    user_mobile: "Please enter mobile",
                    user_email: {
                        required: "Please enter email",
                        email: "Enter valid email"
                    },
                    user_name: {
                        required: "Please enter your name",
                        minlength: "Your name must be at least 2 characters long"
                    },
                    user_country: "Please select country",
                    user_date:{
                      required:"Please select date",
                      valid_date :'Please select valid date'
                    }

                },
                errorPlacement:function(error, element) {
                    error.insertAfter(element);
                },

                submitHandler: function(form) {

                form.submit();
            }

            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>