<html>

<body>

<form action="store" method="post" enctype="multipart/form-data">
    <?php echo e(csrf_field()); ?>

    <?php if(session('status')): ?>
        <div class="alert alert-success">
            <?php echo e(session('status')); ?>

        </div>
    <?php endif; ?>

    <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            There were some problems adding the category.<br />
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

<table>
    <tr>
        <td>Name</td>
        <td><input type="text" name="name" id="name"> </td>
    </tr>
    <tr>
        <td>class</td>
        <td><input type="text" name="class" id="test"> </td>
    </tr>

    <tr>
        <td>File</td>
        <td><input type="file" name="f_name" id="f_name"> </td>
    </tr>

    <tr>
        <td>
            <input type="submit">
        </td>
    </tr>

</table>
</form>
</body>
</html>