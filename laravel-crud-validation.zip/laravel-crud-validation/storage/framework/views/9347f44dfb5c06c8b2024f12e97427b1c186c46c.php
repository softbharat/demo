<html>

<body>
<table>
    <tr>
        <td>Name</td>
    </tr>
    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
    <tr>
        <td><?php echo e($user->user_firstname); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

    <tr>
        <td>
            <?php echo e($users->links()); ?>

        </td>
    </tr>

</table>
</body>
</html>