<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Edit User</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-primary" href="<?php echo e(route('userprofile.index')); ?>"> Back</a>
            </div>
        </div>
    </div>

    <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            There were some problems with your input.<br><br>
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <form name="create" action="<?php echo e(route('userprofile.update', [$user->user_id] )); ?>" method="post" id="update" >
        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" >
        <input type="hidden" name="_method" value="PATCH" >

        <div class="row">
<div class="col-lg-6">
    <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12 ">
                <div class="form-group">
                    <strong>User Name:</strong>

                    <?php if(old('user_name') != ''): ?>
                        <?php 
                            $user->user_name  = old('user_name');
                         ?>
                    <?php elseif($user->user_name != ''): ?>
                        <?php 
                            $user->user_name  = $user->user_name ;
                         ?>
                    <?php else: ?>
                        <?php 
                            $user->user_name  = '' ;
                         ?>
                    <?php endif; ?>
                    <input type="text" name="user_name" id="user_name" placeholder="User Name" class="form-control" value="<?php echo e($user->user_name); ?>">
                </div>
            </div>

            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Email:</strong>
                    <?php if(old('user_email') != ''): ?>
                        <?php 
                            $user->user_email  = old('user_email');
                         ?>
                    <?php elseif($user->user_email != ''): ?>
                        <?php 
                            $user->user_email  = $user->user_email ;
                         ?>
                    <?php else: ?>
                        <?php 
                            $user->user_email  = '' ;
                         ?>
                    <?php endif; ?>
                    <input type="text" name="user_email" id="user_email" placeholder="User Email" class="form-control" value="<?php echo e($user->user_email); ?>">
                </div>
            </div>

            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Mobile:</strong>
                    <?php if(old('user_mobile') != ''): ?>
                        <?php 
                            $user->user_mobile  = old('user_mobile');
                         ?>
                    <?php elseif($user->user_mobile != ''): ?>
                        <?php 
                            $user->user_mobile  = $user->user_mobile ;
                         ?>
                    <?php else: ?>
                        <?php 
                            $user->user_mobile  = '' ;
                         ?>
                    <?php endif; ?>
                    <input type="text" name="user_mobile" id="user_mobile" placeholder="User Mobile" class="form-control" value="<?php echo e($user->user_mobile); ?>">
                </div>
            </div>

            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Country:</strong>
                    <?php if(old('user_country') != ''): ?>
                        <?php 
                            $user->user_country  = old('user_country');
                         ?>
                    <?php elseif($user->user_country != ''): ?>
                        <?php 
                            $user->user_country  = $user->user_country ;
                         ?>
                    <?php else: ?>
                        <?php 
                            $user->user_country  = '' ;
                         ?>
                    <?php endif; ?>

                    <?php 
                        $select_india = '';
                        $select_usa = '';
                        $select_uk = '';
                     ?>
                    <?php if($user->user_country == 'India'): ?>
                        <?php 
                            $select_india = 'selected="selected"';
                         ?>
                    <?php elseif($user->user_country == 'USA'): ?>
                        <?php 
                            $select_usa = 'selected="selected"';
                         ?>
                    <?php elseif($user->user_country == 'UK'): ?>
                        <?php 
                            $select_uk = 'selected="selected"';
                         ?>
                    <?php endif; ?>
                    <select class="form-control" id="user_country" name="user_country">
                        <option value="">Select</option>
                        <option value="India" <?php echo e($select_india); ?>>India</option>
                        <option value="USA" <?php echo e($select_usa); ?>>USA</option>
                        <option value="UK" <?php echo e($select_uk); ?>>UK</option>
                    </select>

                </div>
            </div>


            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Register Date:</strong>
                    <?php if(old('user_date') != ''): ?>
                        <?php 
                            $user->user_date  = old('user_date');
                         ?>
                    <?php elseif($user->user_date != ''): ?>
                        <?php 
                            $user->user_date  = $user->user_date ;
                         ?>
                    <?php else: ?>
                        <?php 
                            $user->user_date  = '' ;
                         ?>
                    <?php endif; ?>
                    <input class="form-control datepicker" id="id_reg" name="user_date" value="<?php echo e($user->user_date); ?>">



                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <?php if(old('user_gender') != ''): ?>
                        <?php 
                            $user->user_gender  = old('user_gender');
                         ?>
                    <?php elseif($user->user_gender != ''): ?>
                        <?php 
                            $user->user_gender  = $user->user_gender ;
                         ?>
                    <?php else: ?>
                        <?php 
                            $user->user_gender  = '' ;
                         ?>
                    <?php endif; ?>
                    <?php 
                        $select_male = '';
                        $select_female = '';

                     ?>
                    <?php if($user->user_gender == 'Male'): ?>
                        <?php 
                            $select_male = 'checked="checked"';
                         ?>
                    <?php elseif($user->user_gender == 'Female'): ?>
                        <?php 
                            $select_female = 'checked="checked"';
                         ?>
                    <?php endif; ?>
                    <strong>Gender:</strong>
                    <div class="form-control" style="border: 0px;">

                        <input type="radio" name="user_gender" id="user_gender" value="Male" <?php echo e($select_male); ?>> Male

                        &nbsp;&nbsp;
                        <input type="radio" name="user_gender" id="user_gender" value="Female" <?php echo e($select_female); ?> > FeMale
                    </div>
                </div>
            </div>


            <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                <button type="submit" class="btn btn-primary">Update</button>
            </div>

        </div>
</div>
        </div>
    </form>

    <script>
        $(document).ready(function() {
            $('.datepicker').datepicker();

            $.validator.addMethod("valid_date", function(value, element) {
                var flag = false;
                var date = value;
                arr_date = date.split('/');
                var day =arr_date[0];
                var mon =arr_date[1];
                var year =arr_date[2];

                if(day<1 || day >31){
                    return false;
                }
                if(mon<1 || mon >12){
                    return false;
                }
                if(year<2010){
                    return false;
                }
                return true;
            }, "");
            // validate signup form on keyup and submit
            $("#update").validate({
                rules: {
                    user_name: {
                        required: true,
                        minlength: 2
                    },
                    user_country: {
                        required: true

                    },
                    user_date: {
                        required: true,
                        valid_date : true
                    },
                    user_email: {
                        required: true,
                        email: true
                    },
                    user_mobile: {
                        required: true,
                        minlength: 10,
                        number:true
                    },

                },
                messages: {

                    user_mobile: "Please enter mobile",
                    user_email: {
                        required: "Please enter email",
                        email: "Enter valid email"
                    },
                    user_name: {
                        required: "Please enter your name",
                        minlength: "Your name must be at least 2 characters long"
                    },
                    user_country: "Please select country",
                    user_date:{
                        required:"Please select date",
                        valid_date :'Please select valid date'
                    }

                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>