<?php $__env->startSection('search_form'); ?>
    <?php if(count($errors) > 0): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                    <li><?php echo e($error); ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form id="question_search_form" name="question_search_form" method="post" action="<?php echo e(route('question.list.index',[$courseid])); ?>">
        <?php echo e(csrf_field()); ?>

        <p>
            <input type="text" class="input-block-level" name="srch_txt" id="srch_txt" placeholder="Enter text to search in question" value="<?php echo e($form_values->srch_txt); ?>">
        </p>
        <p class="clearfix">
            <select id="srch_sct" name="srch_sct" class="col_two_fifth marginB10 marginR10 select2-hidden-accessible" data-placeholder="Search By Section" tabindex="-1" aria-hidden="true">
                <option value=""></option>
                <?php echo $section_list; ?>

            </select>


            &nbsp;&nbsp;
            <select id="srch_dif" name="srch_dif" class="col_one_fifth marginB10 select2-hidden-accessible" data-placeholder="Search By Difficulty" tabindex="-1" aria-hidden="true">
                <option value=""></option>
               <?php echo $diff; ?>


            </select>
            &nbsp;&nbsp;
            <select id="srch_review" name="srch_review" class="col_one_fourth marginB10 col_last select2-hidden-accessible" data-placeholder="Search By Review Status" tabindex="-1" aria-hidden="true">
                <option value=""></option>
               <?php echo $review; ?>


            </select>
        </p>
        <p class="textalignright marginT5">
            <button id="btn_search_question" class="btn btn-info" name="btn_search_question" title="Search Questions" type="submit"><i class="fa fa-search"></i> Search </button>
            <button id="btn_clear_search_question" class="btn btn-primary" name="btn_clear_search_question" title="Clear Search" type="submit"><i class="fa fa-eraser"></i> Clear Search </button>
            <a href="https://flintv5.com:9001/app/course/content/question/?course=MzA3NzQwNDcyMjY=" class="btn btn-success" title="Add Question">
                <i class="fa fa-plus"></i> Add Question
            </a>
            <input type="hidden" value="no" id="view_all_apply" name="view_all_apply">
            <input type="hidden" value="1" id="current_page_index" name="current_page_index">
            <button id="btn_view_all_question" class="btn btn-primary" name="btn_view_all_question" title="Review Questions" type="submit"><i class="fa fa-list"></i> Review Questions</button>
        </p>
    </form>
<?php $__env->stopSection(); ?>



<?php $__env->startSection('question_list'); ?>
    <div class="courselearn-list">
        <div class="col_full head-title">

            <table width="100%">
                <tr>
                    <td>
                          <span class="headcheckbox">
                            <input type="checkbox" id="chk-all" >
                          </span>
                    </td>

                    <td> <h4>

                            Section
                        </h4></td>

                    <td><h4>Question</h4></td>

                    <td> <div class="col_half nobottommargin">
                            <h4>Difficulty</h4>
                        </div>
                    </td>
                <td>
                        <div class="col_half col_last nobottommargin textalignright">
                            <h4>Action</h4>
                        </div></td>
                </tr>


                <?php $__currentLoopData = $question_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $qst): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                <tr>
                    <td>
                        <input type="checkbox" data-cbgroup="question" name="question_selected[]" value="MTE2MzAyOTQxNzk1NA=="/>
                    </td>
                    <td>
                       <?php echo e(Helper::upper_string($qst->section_title)); ?>

                    </td>
                    <td>
                        <h5>
                            <?php echo e($qst->question_description); ?>


                        </h5>
                    </td>
                    <td>
                        <h5> <?php echo e($difficulty_options[$qst->question_difficulty]); ?></h5>
                    </td>
                    <td>
                        <button name="btn_edit" class="test btn btn-info" >EDIT</button>

                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>

            </table>
            <div class="text-center">
                <?php echo e($question_list->appends($_GET)->links()); ?>

            </div>


        </div>


    </div>


<?php $__env->stopSection(); ?>




<?php echo $__env->make('layout.index', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>