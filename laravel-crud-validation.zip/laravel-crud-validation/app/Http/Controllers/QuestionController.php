<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\View;
use App\Question;
use App\Section;
use Illuminate\Support\Facades\DB;
use App\Http\Requests\QuestionForm;

class QuestionController extends Controller
{
    public function index(Request $request,$courseid){
	
	    $difficulty_options = [
		    1 => "High",
		    2 => "Medium",
		    3 => "Low",
	    ];
	
	
	  $buuton = Input::all();
	   if(isset($buuton['btn_clear_search_question'])) {
		   return  redirect()->route('question.list.index',['courseid' => $courseid]);
	   }
	   
	    if(isset($buuton['btn_search_question'])) {
		    // Execute validation manually
		    app('App\Http\Requests\QuestionForm');
	    }
		
	    /* ajax example*/
	    if(Input::get('name') && Input::get('id')) {
	   	    if(Input::get('name') == 'Bharat'){
	   	    	$name = 'Bharat K Rawal';
	        }
	        if(Input::get('id') == '101'){
		        $class = 'MCA';
	        }
	        
		    $response = array(
			    'status' => 'success',
			    'msg' => 'Setting created successfully',
			    'name'=>$name,
			    'class'=>$class
		    );
		    return response()->json($response);
	    }
	    /* ajax example*/
	    
	    
	    $question_list = $this->question_list($courseid);
	  
	   
	    $section_list = $this->section_list($courseid, $request);
	    $dif = $this->oplist($difficulty_options, $request);
	    $review = $this->opreview($request);
	    
    	return View::make('content-question-list-course',['courseid'=>$courseid,'question_list'=>$question_list,'difficulty_options'=>$difficulty_options,'section_list'=>$section_list,
		    'diff'=>$dif,'review'=>$review,'form_values'=>$request]);
    }
	
	public function question_list($course_id) {
		
		$test =  DB::table('flt_lms_sections')
			->leftjoin('flt_courses','flt_courses.course_id','=','flt_lms_sections.course_id')
			->leftjoin('icon_questions',function ($join)
			{
				$join->on('icon_questions.question_subject_id','=','flt_lms_sections.section_id');
				$join->on('icon_questions.question_module_id','=','flt_courses.course_id');
			})
			->where('icon_questions.question_module_id', '=', $course_id)
			->where('icon_questions.question_is_deleted', '=', 0)
			->where('flt_lms_sections.section_deleted', '=', 0)
			->select('icon_questions.question_id','flt_lms_sections.section_title', 'icon_questions.question_description', 'icon_questions.question_difficulty')
			->paginate(10);
		//->toSql();
		return $test;
	}
	
	public function section_list($course_id, $form_values){
		
		$result = Section::where('course_id',$course_id)
			->where('section_deleted',0)
			->select('section_id','section_title')
			->orderBy('section_srno')
			->get();

		$section_options = '';
		
		foreach ($result as $sec){
			
			$section_options .= '<option value="' . $sec->section_id . '" %s';
			$section_options .= ' >' . $sec->section_title . '</option>' . '\n';
			
			// when edit page is opened, show saved section as selected
			$section_options = sprintf($section_options, ($sec->section_id ==
			$form_values['srch_sct'] ? ' selected="selected" ' : ''));
		}
		return $section_options;
	}
	
	public function oplist($difficulty_options, $form_values){
		$options="";
		for($i=1;$i<=count($difficulty_options);$i++) {
			$sel = '';
			if($form_values['srch_dif']==$i){
				$sel = 'selected="selected"';
			}
			$options.="<option $sel value=".$i.">".$difficulty_options[$i]."</option>";
		}
		return $options;
	}
	
	public function opreview( $form_values){
		$reviewlist_options = array('any'=>'Any', 'reviewed'=>'Reviewed', 'notreviewed'=>'Not Reviewed');
		$options="";
		foreach ($reviewlist_options as $reviewlist_option=>$reviewlist){
			$sel = '';
			if($form_values['srch_review']==$reviewlist_option){
				$sel = 'selected="selected"';
			}
			$options.="<option $sel value=".$reviewlist_option.">".$reviewlist."</option>";
		}
		return $options;
	}
	
}
