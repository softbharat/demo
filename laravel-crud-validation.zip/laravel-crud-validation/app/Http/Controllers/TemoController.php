<?php
//https://laracasts.com/discuss/channels/general-discussion/i-want-to-learn-to-build-my-own-service-providers
namespace App\Http\Controllers;

use App\Helpers\Helper;
use Illuminate\Http\Request;
use App\Helpers\Contracts\RocketShipContract;
use Illuminate\Support\Facades\URL;

class TemoController extends Controller
{
	public function index(RocketShipContract $rocketship)
	{
		
		$boom = $rocketship->blastOff();
		$soom = $rocketship->blastOn();
		//custome heper function
			echo Helper::shout('api testing');
		echo '<br/>'.Helper::con_c('Bharat','Rawal');
		
		echo '<br/>'.$soom;
		
		echo '<br/>'.URL::full();
		//echo '<br/>'. URL::route('');
		return view('demo.index', compact('boom'));
		
	}
	
}
