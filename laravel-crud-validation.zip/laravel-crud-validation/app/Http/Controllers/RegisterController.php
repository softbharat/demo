<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use App\UserProfile;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Redirect;

class RegisterController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
	    $users= UserProfile::orderBy('user_id','DESC')->paginate(5);
	    return view('userprofile.index',compact('users'))->with('i', ($request->input('page', 1) - 1) * 5);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
	    return view('userprofile.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
	    Validator::extend('checkRegdate', function($field, $value, $parameters) {
	    	$date_arr = explode("/",$value);
		    $day =$date_arr[0];
		    $mon =$date_arr[1];
		    $year =$date_arr[2];
		    
		    if($year<2015){
			    return false;
		    }
		    
		    return true;
	    },'Date greater than 2015');
	
	    
	    // create the validation rules
	    $rules = array(
		    'user_name' => 'required|min:10',
		    'user_email' => 'required|email',
		    'user_mobile' => 'required|digits:10',
		    'user_country' => 'required',
		    'user_date' => 'required|checkRegdate',
	    );
	
	    // validate against the inputs from our form
	    $validator = Validator::make(Input::all(), $rules);
	
	    // check if the validator failed -----------------------
	    if ($validator->fails()) {
		    // redirect our user back to the form with the errors from the validator
		    return Redirect::to('userprofile/create')
			    ->withErrors($validator)->withInput();
	    } else {
		    $user = new UserProfile();
		    $user->user_name = Input::get('user_name');
		    $user->user_email = Input::get('user_email');
		    $user->user_mobile = Input::get('user_mobile');
		    $user->user_login = Input::get('user_email');
		    $user->user_password = Input::get('user_mobile');
		    $user->user_firstname = Input::get('user_name');
		    $user->user_lastname =  Input::get('user_name');
		    $user->user_acc_type = '1';
		    $user->user_gender = Input::get('user_gender');
		    $user->user_country = Input::get('user_country');
		    //$user->user_date = time();
		    $user->user_updated = time();
		
		    $user->save();
		    return redirect()->route('userprofile.index')
			    ->with('success','User created successfully');
		
	    }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
	    $user = UserProfile::find($id);
	    return view('userprofile.show',compact('user'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
	    $user = UserProfile::find($id);
	    
	    return view('userprofile.edit',compact('user'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
	    Validator::extend('checkRegdate', function($field, $value, $parameters) {
		    $date_arr = explode("/",$value);
		    $day =$date_arr[0];
		    $mon =$date_arr[1];
		    $year =$date_arr[2];
		
		    if($year<2015){
			    return false;
		    }
		
		    return true;
	    },'Date greater than 2015');
	
	
	    // create the validation rules
	    $rules = array(
		    'user_name' => 'required|min:10',
		    'user_email' => 'required|email',
		    'user_mobile' => 'required|digits:10',
		    'user_country' => 'required',
		    'user_date' => 'required|checkRegdate',
	    );
	
	    // validate against the inputs from our form
	    $validator = Validator::make(Input::all(), $rules);
	
	    // check if the validator failed -----------------------
	    if ($validator->fails()) {
		    // redirect our user back to the form with the errors from the validator
		    return Redirect::back()
			    ->withErrors($validator)->withInput();
	    } else {
		    unset($request->user_date);
		    UserProfile::find($id)->update($request->all());
		    return redirect()->route('userprofile.index')
			    ->with('success','User updated successfully');
	    }
	    
		
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
	    UserProfile::find($id)->delete();
	    return redirect()->route('userprofile.index')
		    ->with('success','User deleted successfully');
    }
    
}
