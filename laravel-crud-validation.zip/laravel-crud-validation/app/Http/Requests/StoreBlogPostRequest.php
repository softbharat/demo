<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Factory;

class StoreBlogPostRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }
	
	public function __construct(Factory $factory)
	{
		$factory->extend('test', function ($attribute, $value, $parameters)
		{
			if($value>51){
				return true;
			} else{
				return false;
			}
			
		},
			'Bad number format'
		);
	}
    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
	        'name' => 'required|max:2|test',
	        'class' => 'min:2',
        ];
    }
}
