<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;
class Question extends Model
{
    protected $primaryKey = 'question_id';
	protected $table ='icon_questions';
}
