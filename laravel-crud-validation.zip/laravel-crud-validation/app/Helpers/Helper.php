<?php
/**
 * Created by PhpStorm.
 * User: flinnt-php-3
 * Date: 19/4/17
 * Time: 12:06 PM
 */
namespace App\Helpers;

class Helper{
	public static function shout($string)
	{
		return strtoupper($string);
	}
	
	public static function con_c($first, $second){
		return $first . '_'. $second;
	}
	public static function upper_string($string){
		return strtoupper($string);
	}
	
}