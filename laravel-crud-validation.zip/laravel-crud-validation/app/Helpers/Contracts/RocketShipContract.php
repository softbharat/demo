<?php

namespace App\Helpers\Contracts;

Interface RocketShipContract
{
	
	public function blastOff();
	public function blastOn();
	
	
}
