@extends('layout.default')

@section('content')

    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>CRUD Operation</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-success" href="{{ route('userprofile.create') }}"> Add New User</a>
            </div>
        </div>
    </div>

    @if ($message = Session::get('success'))
        <div class="alert alert-success">
            <p>{{ $message }}</p>
        </div>
    @endif

    <table class="table table-bordered">
        <tr>
            <th>No</th>
            <th>Name</th>
            <th>Email</th>
            <th>Mobile</th>
            <th >Action</th>
        </tr>
        @foreach ($users as $key => $item)
            <tr>
                <td>{{ ++$i }}</td>
                <td>{{ $item->user_name }}</td>
                <td>{{ $item->user_email }}</td>
                <td>{{ $item->user_mobile }}</td>
                <td>
                    <a class="btn btn-info" href="{{ route('userprofile.show',$item->user_id) }}">Show</a>
                    <a class="btn btn-primary" href="{{ route('userprofile.edit',$item->user_id) }}">Edit</a>
                    <form style="display: inline-table;" action="{{ route('userprofile.destroy', [$item->user_id] ) }}" method="post">
                        <input type="hidden" name="_token" value="{{ csrf_token() }}" >
                        <input type="hidden" name="_method" value="DELETE" >
                        <button type="submit" class="btn btn-danger">Delete</button>
                     </form>
                </td>
            </tr>
        @endforeach
    </table>

    {!! $users->render() !!}

@endsection