@extends('layout.default')

@section('content')

    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>Edit User</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-primary" href="{{ route('userprofile.index') }}"> Back</a>
            </div>
        </div>
    </div>

    @if (count($errors) > 0)
        <div class="alert alert-danger">
            There were some problems with your input.<br><br>
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif
    <form name="create" action="{{ route('userprofile.update', [$user->user_id] ) }}" method="post" id="update" >
        <input type="hidden" name="_token" value="{{ csrf_token() }}" >
        <input type="hidden" name="_method" value="PATCH" >

        <div class="row">
<div class="col-lg-6">
    <div class="row">
            <div class="col-xs-12 col-sm-12 col-md-12 ">
                <div class="form-group">
                    <strong>User Name:</strong>

                    @if(old('user_name') != '')
                        @php
                            $user->user_name  = old('user_name');
                        @endphp
                    @elseif($user->user_name != '')
                        @php
                            $user->user_name  = $user->user_name ;
                        @endphp
                    @else
                        @php
                            $user->user_name  = '' ;
                        @endphp
                    @endif
                    <input type="text" name="user_name" id="user_name" placeholder="User Name" class="form-control" value="{{ $user->user_name }}">
                </div>
            </div>

            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Email:</strong>
                    @if(old('user_email') != '')
                        @php
                            $user->user_email  = old('user_email');
                        @endphp
                    @elseif($user->user_email != '')
                        @php
                            $user->user_email  = $user->user_email ;
                        @endphp
                    @else
                        @php
                            $user->user_email  = '' ;
                        @endphp
                    @endif
                    <input type="text" name="user_email" id="user_email" placeholder="User Email" class="form-control" value="{{ $user->user_email  }}">
                </div>
            </div>

            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Mobile:</strong>
                    @if(old('user_mobile') != '')
                        @php
                            $user->user_mobile  = old('user_mobile');
                        @endphp
                    @elseif($user->user_mobile != '')
                        @php
                            $user->user_mobile  = $user->user_mobile ;
                        @endphp
                    @else
                        @php
                            $user->user_mobile  = '' ;
                        @endphp
                    @endif
                    <input type="text" name="user_mobile" id="user_mobile" placeholder="User Mobile" class="form-control" value="{{ $user->user_mobile }}">
                </div>
            </div>

            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Country:</strong>
                    @if(old('user_country') != '')
                        @php
                            $user->user_country  = old('user_country');
                        @endphp
                    @elseif($user->user_country != '')
                        @php
                            $user->user_country  = $user->user_country ;
                        @endphp
                    @else
                        @php
                            $user->user_country  = '' ;
                        @endphp
                    @endif

                    @php
                        $select_india = '';
                        $select_usa = '';
                        $select_uk = '';
                    @endphp
                    @if($user->user_country == 'India')
                        @php
                            $select_india = 'selected="selected"';
                        @endphp
                    @elseif($user->user_country == 'USA')
                        @php
                            $select_usa = 'selected="selected"';
                        @endphp
                    @elseif($user->user_country == 'UK')
                        @php
                            $select_uk = 'selected="selected"';
                        @endphp
                    @endif
                    <select class="form-control" id="user_country" name="user_country">
                        <option value="">Select</option>
                        <option value="India" {{ $select_india }}>India</option>
                        <option value="USA" {{ $select_usa }}>USA</option>
                        <option value="UK" {{ $select_uk }}>UK</option>
                    </select>

                </div>
            </div>


            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    <strong>Register Date:</strong>
                    @if(old('user_date') != '')
                        @php
                            $user->user_date  = old('user_date');
                        @endphp
                    @elseif($user->user_date != '')
                        @php
                            $user->user_date  = $user->user_date ;
                        @endphp
                    @else
                        @php
                            $user->user_date  = '' ;
                        @endphp
                    @endif
                    <input class="form-control datepicker" id="id_reg" name="user_date" value="{{ $user->user_date}}">



                </div>
            </div>
            <div class="col-xs-12 col-sm-12 col-md-12">
                <div class="form-group">
                    @if(old('user_gender') != '')
                        @php
                            $user->user_gender  = old('user_gender');
                        @endphp
                    @elseif($user->user_gender != '')
                        @php
                            $user->user_gender  = $user->user_gender ;
                        @endphp
                    @else
                        @php
                            $user->user_gender  = '' ;
                        @endphp
                    @endif
                    @php
                        $select_male = '';
                        $select_female = '';

                    @endphp
                    @if($user->user_gender == 'Male')
                        @php
                            $select_male = 'checked="checked"';
                        @endphp
                    @elseif($user->user_gender == 'Female')
                        @php
                            $select_female = 'checked="checked"';
                        @endphp
                    @endif
                    <strong>Gender:</strong>
                    <div class="form-control" style="border: 0px;">

                        <input type="radio" name="user_gender" id="user_gender" value="Male" {{$select_male}}> Male

                        &nbsp;&nbsp;
                        <input type="radio" name="user_gender" id="user_gender" value="Female" {{$select_female}} > FeMale
                    </div>
                </div>
            </div>


            <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                <button type="submit" class="btn btn-primary">Update</button>
            </div>

        </div>
</div>
        </div>
    </form>

    <script>
        $(document).ready(function() {
            $('.datepicker').datepicker();

            $.validator.addMethod("valid_date", function(value, element) {
                var flag = false;
                var date = value;
                arr_date = date.split('/');
                var day =arr_date[1];
                var mon =arr_date[0];
                var year =arr_date[2];

                if(day<1 || day >31){
                    return false;
                }
                if(mon<1 || mon >12){
                    return false;
                }
                if(year<2010){
                    return false;
                }
                return true;
            }, "");
            // validate signup form on keyup and submit
            $("#update").validate({
                rules: {
                    user_name: {
                        required: true,
                        minlength: 2
                    },
                    user_country: {
                        required: true

                    },
                    user_date: {
                        required: true,
                        valid_date : true
                    },
                    user_email: {
                        required: true,
                        email: true
                    },
                    user_mobile: {
                        required: true,
                        minlength: 10,
                        number:true
                    },

                },
                messages: {

                    user_mobile: "Please enter mobile",
                    user_email: {
                        required: "Please enter email",
                        email: "Enter valid email"
                    },
                    user_name: {
                        required: "Please enter your name",
                        minlength: "Your name must be at least 2 characters long"
                    },
                    user_country: "Please select country",
                    user_date:{
                        required:"Please select date",
                        valid_date :'Please select valid date'
                    }

                }
            });
        });
    </script>
@endsection