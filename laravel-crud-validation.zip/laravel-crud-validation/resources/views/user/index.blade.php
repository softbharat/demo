<html>

<body>
<table>
    <tr>
        <td>Name</td>
    </tr>
    @foreach($users as $user)
    <tr>
        <td>{{ $user->user_firstname }}</td>
    </tr>
    @endforeach

    <tr>
        <td>
            {{ $users->links() }}
        </td>
    </tr>

</table>
</body>
</html>