<html>

<body>

<form action="store" method="post" enctype="multipart/form-data">
    {{ csrf_field() }}
    @if (session('status'))
        <div class="alert alert-success">
            {{ session('status') }}
        </div>
    @endif

    @if (count($errors) > 0)
        <div class="alert alert-danger">
            There were some problems adding the category.<br />
            <ul>
                @foreach ($errors->all() as $error)
                    <li>{{ $error }}</li>
                @endforeach
            </ul>
        </div>
    @endif

<table>
    <tr>
        <td>Name</td>
        <td><input type="text" name="name" id="name"> </td>
    </tr>
    <tr>
        <td>class</td>
        <td><input type="text" name="class" id="test"> </td>
    </tr>

    <tr>
        <td>File</td>
        <td><input type="file" name="f_name" id="f_name"> </td>
    </tr>

    <tr>
        <td>
            <input type="submit">
        </td>
    </tr>

</table>
</form>
</body>
</html>