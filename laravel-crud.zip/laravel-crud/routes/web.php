<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/', function () {
	return view('index');
});

Route::resource('userprofile','RegisterController');





Route::get('home', function () {
	// Retrieve a piece of data from the session...
	echo $value = session('key');
	
	// Specifying a default value...
	echo $value = session('key', 'default');
	
	// Store a piece of data in the session...
	session(['key' => '2563','name'=>'Bharat']);
	
	
	
});

/*Route::get('/', function () {
    return view('welcome');
});*/

Route::get('dd', 'DemoController@index');
Route::get('provider', 'TemoController@index');
Route::get('user', 'UserController@index');

//Route::get('class', 'DemoController');

Route::get('user/register', 'UserController@register');
Route::post('user/store', 'UserController@store');


/*Route::get('demo',function (){
	//return 'hellow';
	//return [1,2,3];
	//return response('Hello',200)->header('Content-Type','text/plain');
	/*return response('USER ADMIN')
		->header('Content-Type', 'text/plain')
		->header('X-Header-One', 'Header Value')
		->header('X-Header-Two', 'Header Value');*/
	//return redirect('user');
	//return redirect('user/register')->with('status', 'Profile updated!');
	
/*	return response()->json([
		'name' => 'Abigail',
		'state' => 'CA'
	]);
});*/
/*
Route::group(['prefix' => LaravelLocalization::setLocale(),'middleware' => [ 'localeSessionRedirect', 'localizationRedirect' ]], function()
{
	Route::group(['prefix' => 'admin','middleware' => 'auth','namespace' => 'Admin'],function(){
		Route::resource('customers', 'CustomersController');
		Route::resource('brands', 'BrandsController');
		Route::resource('product-categories', 'ProductCategoriesController');
		Route::resource('products', 'ProductsController');
		Route::resource('users', 'UsersController');
		
		Route::get('orders',[
			'uses' => 'OrdersController@index',
			'as' => 'orders.index',
		]);
	});
	
	// Authentication Routes...
	$this->get('admin/login', 'Auth\LoginController@showLoginForm')->name('login');
	$this->post('admin/login', 'Auth\LoginController@login');
	$this->post('admin/logout', 'Auth\LoginController@logout')->name('logout');
	
	// Password Reset Routes...
	$this->get('admin/password/reset', 'Auth\ForgotPasswordController@showLinkRequestForm')->name('password.reset');
	$this->post('admin/password/email', 'Auth\ForgotPasswordController@sendResetLinkEmail')->name('password.email');
	$this->get('admin/password/reset/{token}', 'Auth\ResetPasswordController@showResetForm')->name('password.reset.token');
	$this->post('admin/password/reset', 'Auth\ResetPasswordController@reset');
});*/






























/**
 * ALL AT ONE PLACE
 */
/*Route::get('course/content/question-list/{courseid}',
	['as'=>'question.list.index','uses'=>'QuestionController@index']
);*/
//old -https://flintv5.com:9001/app/course/content/question-list/?course=NTk0NzYwNDg1MjU=
Route::match(
	['get', 'post'], 'course/content/question-list/{courseid}',
	['as'=>'question.list.index','uses'=>'QuestionController@index']
);