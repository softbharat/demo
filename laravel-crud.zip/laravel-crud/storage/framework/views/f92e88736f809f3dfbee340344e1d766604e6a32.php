<?php $__env->startSection('content'); ?>

    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2>CRUD Operation</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-success" href="<?php echo e(route('userprofile.create')); ?>"> Add New User</a>
            </div>
        </div>
    </div>

    <?php if($message = Session::get('success')): ?>
        <div class="alert alert-success">
            <p><?php echo e($message); ?></p>
        </div>
    <?php endif; ?>

    <table class="table table-bordered">
        <tr>
            <th>No</th>
            <th>Name</th>
            <th>Email</th>
            <th>Mobile</th>
            <th width="280px">Action</th>
        </tr>
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <tr>
                <td><?php echo e(++$i); ?></td>
                <td><?php echo e($item->user_name); ?></td>
                <td><?php echo e($item->user_email); ?></td>
                <td><?php echo e($item->user_mobile); ?></td>
                <td>
                    <a class="btn btn-info" href="<?php echo e(route('userprofile.show',$item->user_id)); ?>">Show</a>
                    <a class="btn btn-primary" href="<?php echo e(route('userprofile.edit',$item->user_id)); ?>">Edit</a>
                   
                    <form  action="<?php echo e(route('userprofile.destroy', [$item->user_id] )); ?>" method="post">
                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" >
                        <input type="hidden" name="_method" value="DELETE" >
                        <button type="submit" class="btn btn-danger">Delete</button>
                     </form>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
    </table>

    <?php echo $users->render(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.default', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>