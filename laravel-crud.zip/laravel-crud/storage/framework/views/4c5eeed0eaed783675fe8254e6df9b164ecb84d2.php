<html dir="ltr" lang="en-US" class="csstransforms csstransforms3d csstransitions flash no-ie8compat svg audio canvas video canvastext emoji">
    <head>
        <link rel="stylesheet" type="text/css" media="all" href="<?php echo e(asset('css/style.css?20102015164255')); ?>">
        <link rel="stylesheet" type="text/css" media="all" href="<?php echo e(asset('css/bootstrap.css?20102015164255')); ?>">
    </head>
<body class="stretched">
<div id="wrapper" class="clearfix">
    <div id="header" class="header2">
        <div class="container clearfix">
        </div>
    </div>
    <div id="content">
        <div id="page-title" class="paddingT10 padingB10">

            <div class="container clearfix">

                <h1><a href="https://flintv5.com:9001/GITS/649q8vy2/abc-private/">ABC Private</a> / Question List</h1>

            </div>

        </div>

        <div class="content-wrap">
            <div class="container clearfix">
                <div class="nobottommargin clearfix">

                    <div id="question_list_container">



                        <div>
                            <?php echo $__env->yieldContent('search_form'); ?>


                        </div>



                        <div>
                            <form class="" method="post" action="<?php echo e(route('question.list.index',[$courseid])); ?>" id="question_list_form" name="question_list_form">
                                <?php echo $__env->yieldContent('question_list'); ?>


                                <div class="col_full head-title">
                                    <div class="col_full nobottommargin ">
                                        <button type="button" name="btn_question_options" id="btn_question_options" class="btn btn-sm btn-danger" data-value="NDc1OXJ5Y3ZneWh6X3JncnlycV9hYnZncG5fZmZuejYyMjI=">
                                            <i class="fa fa-times"></i> Delete selected
                                        </button>
                                        <input type="hidden" name="mass_action" id="mass_action">
                                        <div class="demo_version"></div>
                                    </div>
                                </div>



                            </form>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <script type="text/javascript" src="<?php echo e(asset('js/jquery.js')); ?>"></script>
        <script type="text/javascript">
            $( document ).ready( function( $ ) {
                $("#btn_question_options").on('click', function () {

                    $.ajax({
                        type: 'POST',
                        url: '<?php echo Request::fullUrl(); ?>',
                        data: {'id':101,'name':'Bharat','_token':'<?php echo csrf_token();?>'},
                        datatype: 'json',
                        success: function(resp, status, xhr) {
                            //console.log(resp);
                            $('.demo_version').html('');
                            $('.demo_version').append(resp.name + ' of ' + resp.class+ ' has ' +resp.msg);
                        },
                        error: function(xhr, status, err) {
                            that.loader.html('');
                            if(typeof xhr.responseJSON != "undefined") {
                                var resp=xhr.responseJSON;
                                _.has(resp, "stat") && resp.stat == 0 ? _.has(resp, "reload") && resp.reload == 1 ? location.reload() : "" : "";
                            }
                        }
                    });
                });


                $(".test").click(function(e) {
                    e.preventDefault();
                    $(this).closest('tr').css('color','red');
                });
            });
        </script>


    </div>
    <div id="footer-section">
        <div id="twitter-panel">

            <div class="container clearfix">

                <div class="footer_app">

                </div>

                <div class="socialmedia">
                    <a href="https://www.facebook.com/Myflinnt" target="_blank" class="fbicon"><i class="fa fa-facebook" aria-hidden="true"></i></a>
                    <a href="http://twitter.com/Flinnts" target="_blank" class="twitter-icon"><i class="fa fa-twitter" aria-hidden="true"></i></a>
                    <a href="https://plus.google.com/+Flinnt/" target="_blank" class="google-icon"><i class="fa fa-google-plus" aria-hidden="true"></i></a>
                    <a href="https://www.linkedin.com/company/flinnt" target="_blank" class="linkdin-icon"><i class="fa fa-linkedin" aria-hidden="true"></i></a>
                </div>

            </div>
        </div>

        <div id="footer" class="footer-dark">
            <div class="container clearfix">
                <div class="footer-widgets-wrap clearfix">
                    <div class="col_half">
                        <div class="widget portfolio-widget clearfix">
                            <div class="col_full nomargin">
                                <h4 class="widget-title">About flinnt</h4>
                            </div>

                        </div>
                        <p style="text-align: justify">Flinnt is a social learning platform where learners can join courses provided by institutions and experts. Institutions and experts can communicate and teach online to deliver engaging learning experiences.</p>
                        <p style="text-align: justify">On Flinnt learners can access courses provided by; Graduate and Postgraduate Institutions, K-12 Schools, Kindergartens, Subject Matter Experts, Content Providers, Publishers, Training Providers, Seminar and Conference Organizers, Tutorials and Examination Coaching Centers.</p>
                        <div class="contact-email">
                            <ul class="fa-ul">
                                <li><i class="fa fa-li fa-phone"></i>0-79-4014-9800</li>
                                <li><i class="fa fa-li fa-envelope-o"></i><a href="mailto:hello@flinnt.com">hello@flinnt.com</a></li>
                            </ul>

                        </div>
                    </div>

                    <div class="col_one_fourth">

                        <div id="linkcat-2" class="widget widget_links clearfix">
                            <h4 class="widget-title">Links</h4>
                            <ul class="xoxo blogroll">
                                <li><a href="https://flintv5.com:9001/app/static/privacy/">Privacy Policy</a></li>
                                <li><a href="https://flintv5.com:9001/app/static/terms/">Terms of Service</a></li>
                                <li><a href="https://flintv5.com:9001/app/static/cancellation/">Cancellations and Returns</a></li>
                                <li><a href="https://flintv5.com:9001/app/static/shipping/" class="noleftmargin">Shipping Policy</a></li>
                                <li><a href="http://blog.flinnt.com" target="_blank">Blog</a></li>
                                <li><a href="https://flintv5.com:9001/app/static/about_us/">About Us</a></li>
                                <li><a href="https://flintv5.com:9001/app/contact/">Contact Us</a></li>
                            </ul>
                        </div>
                    </div>



                </div>
            </div>
        </div>
        <div class="clear"></div>
        <div id="copyrights" class="copyrights-dark">
            <div class="container clearfix">
                <div class="col_full"> Copyrights © 2017 &amp; All Rights Reserved by Concepts iconnect Pvt. Ltd.  </div>

                <!-- Page loaded in 0.20963096618652 seconds! -->
            </div>
        </div>
    </div>

</div>








</body></html>