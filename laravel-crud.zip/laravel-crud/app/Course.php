<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Course extends Model
{
	/**
	 * The table associated with the model.
	 *
	 * @var string
	 */
	protected $table = 'flt_courses';
	
	public $primaryKey = 'course_id';
	
	public $timestamps = false;
	
	protected $fillable = array('course_name', 'course_username');
	protected $guarded = array('course_owner');
}
