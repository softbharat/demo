<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\UserProfile;
use Illuminate\Support\Facades\Input;

class RegisterController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
	    $users= UserProfile::orderBy('user_id','DESC')->paginate(5);
	    return view('userprofile.index',compact('users'))
		    ->with('i', ($request->input('page', 1) - 1) * 5);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
	    return view('userprofile.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
	    $this->validate($request, [
		    'user_name' => 'required',
		    'user_email' => 'required',
		    'user_mobile' => 'required',
	    ]);
	
	    //UserProfile::create($request->all());
	    $user = new UserProfile();
	    $user->user_name = Input::get('user_name');
	    $user->user_email = Input::get('user_email');
	    $user->user_mobile = Input::get('user_mobile');
	    $user->user_login = Input::get('user_email');
	    $user->user_password = Input::get('user_mobile');
	    $user->user_firstname = Input::get('user_name');
	    $user->user_lastname =  Input::get('user_name');
	    $user->user_acc_type = '1';
	    $user->user_updated = time();
	    $user->save();
	    return redirect()->route('userprofile.index')
		    ->with('success','User created successfully');
	
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
	    $user = UserProfile::find($id);
	    return view('userprofile.show',compact('user'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
	    $user = UserProfile::find($id);
	    return view('userprofile.edit',compact('user'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
	    $this->validate($request, [
		    'user_name' => 'required',
		    'user_email' => 'required',
		    'user_mobile' => 'required',
	    ]);
	
	    UserProfile::find($id)->update($request->all());
	    return redirect()->route('userprofile.index')
		    ->with('success','User updated successfully');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
	    UserProfile::find($id)->delete();
	    return redirect()->route('userprofile.index')
		    ->with('success','User deleted successfully');
    }
    
}
