<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Controller;
use App\Course;
use Illuminate\Support\Facades\Session;
use App\Http\Requests\StoreBlogPostRequest;
class UserController extends Controller
{
    //
	/**
	 * Show a list of all of the application's users.
	 *
	 * @return Response
	 */
	public function index()
	{
		//$users = DB::table('flt_users')->get();
		
		//$user = DB::table('flt_users')->where('user_name', 'rohitinst')->first();
		//echo $user->user_firstname;
		$user = DB::table('flt_users')->select('user_email')->where('user_name', 'rohitinst')->first();
		
		echo $user->user_email;
		
		$total =  DB::table("flt_users")->count();
		echo '<br/>'.$total;
		
		
		$user = DB::table('flt_users')->select('user_email','user_firstname as fullname')->where('user_name', 'rohitinst')->first();
		
		echo '<br/>'. $user->user_email;
		echo '<br/>'. $user->fullname;
		//$users = DB::table('flt_users')->where('user_firstname','Rajat9')->first();
		
		$users = DB::table('flt_users')->where('user_firstname','=','Riyansh5')->orwhere('user_firstname','=','Riyansh4')->get();
		
		//echo '<pre>'. print_r($users);
		//return view('user.index', ['users' => $users]);
		
		$users = DB::table('flt_users')->paginate('5');
		//return view('user.index', ['users' => $users]);
		//INSERT INTO flt_states (state_name,country_id) VALUES('TEST','121');
		/*$data = DB::table("flt_states")
			->insert([
			['state_name'=>'A','country_id'=>'22'],
			['state_name'=>'B','country_id'=>'23']
		]);*/
		/*$data = DB::table("flt_states")
			->insertGetId(
				['state_name'=>'A','country_id'=>'22']
			);
		if($data){
			echo 'inserted id'.$data;
		}
		*/
		
		/*$data = DB::table('flt_states')
			->where('state_id', 35)
			->update(
				['state_name' => 'TRS','sr_no' => 55]
			);
		if($data){
			echo 'updated';
		}*/
		
		$data = DB::table('flt_states')
			->where('state_id', 36)
			->delete();
		
		/*SELECT c.course_id, uc.user_mod_role_id, u.user_id FROM flt_courses c LEFT JOIN flt_user_courses uc ON c.course_id = uc.user_mod_course_id LEFT JOIN flt_users u ON u.user_id = uc.user_mod_user_id WHERE c.course_is_free=1 AND c.course_public = 0 AND u.user_id = '5971' AND c.course_owner = '5577'
	*/
		/*$course = DB::table('flt_courses c')
			->leftJoin('flt_user_courses uc','c.course_id','=','uc.user_mod_course_id')
			->leftJoin('flt_users u','u.user_id','=','uc.user_mod_user_id')
			->select('c.course_id', 'uc.user_mod_role_id', 'u.user_id')
			->where('c.course_is_free','1')
			->where('c.course_public','0')
			->where('u.user_id','5971')
			->where('c.course_owner','5577')->get()
			;
		print_r($course);*/
		/*$users = DB::table('flt_users')
			->leftJoin('flt_user_courses', 'flt_users.user_id', '=', 'flt_user_courses.user_mod_user_id')
			->get();
		print_r($users);*/
		
		
		//$courses = Course::all();
		/*$courses = Course::where('course_id', 2)->get();
		
		foreach ($courses as $flight) {
			echo '<br/>'. $flight->course_name;
			echo '---' .$flight->course_owner;
			
		}*/
		echo '<br/>'. base_path();
		echo '<br/>'. app_path();
		echo '<br/>'. config_path();
		echo '<br/>'. database_path();
		echo '<br/>'. public_path();
		
		echo '<br/>'.$url = action('UserController@index');
		echo '<br/>'. url('user');
		echo '<br/>'.$value = cache('key');
		echo '<br/>'.$value = config('app.timezone');
		echo '<br/>'.$token = csrf_token();
		echo '<br/>'.$env = env('APP_ENV');
		$request = request();
		Session::put(['chairs' => 7, 'instruments' => 3,'key','12345']);
		echo '<br/>'.$value = Session::get('key');
		echo '<br/>'.$value = session('key');
		echo '<br/>'.$value = session('instruments');
		//abort(401);
		//echo '<br/>'. $url = route('routeName');
	}
	
	public function store(StoreBlogPostRequest $request){
		if ($request->isMethod('post')) {
			echo '<br/>'.$name = $request->input('name');
			echo '<br/>'.$name = $request->name;
			echo '<br/>'.$name = $request->file('f_name');
			
			//$path = $request->f_name->store('images');
			echo '<br/>'.$file = $request->f_name;
			if($file!=''){
				echo '<br/>'.$path = $request->f_name->path();
				
				echo '<br/>'.$extension = $request->f_name->extension();
				$imageName = time().'.'.$request->f_name->getClientOriginalExtension();
				$request->f_name->move(public_path('images'), $imageName);
			}
			
			
		}
		
	}
	public function register(){
		
		return view('user.register');
	}
}
