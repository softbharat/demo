<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
class DemoController extends Controller
{
	public function index(Request $request){
		$a = $request->session()->all();
		print_r($a);
		
	}
}
/*class DemoController extends Controller
{
	static $state ='static';
	const STATE = 'GUJRAT';
	public $pub ='Public';
	private $pri = 'Private';
	protected $prot = 'Protected';
	
	function __construct()
	{
		
	}
	
	public function showme(){
		echo '<br/> st'.self::$state;
		echo '<br/> con'.self::STATE;
		echo '<br/> pu'.$this->pub;
		echo '<br/> pr'.$this->pri;
		echo '<br/> prot'.$this->prot;
	}
	
	private function showme1(){
		echo '<br/> st'.self::$state;
		echo '<br/> con'.self::STATE;
		echo '<br/> pu'.$this->pub;
		echo '<br/> pr'.$this->pri;
		echo '<br/> prot'.$this->prot;
	}
	
	protected function showme2(){
		echo '<br/> st'.self::$state;
		echo '<br/> con'.self::STATE;
		echo '<br/> pu'.$this->pub;
		echo '<br/> pr'.$this->pri;
		echo '<br/> prot'.$this->prot;
	}
}*/

//$obj = new DemoController();
//$obj->showme();

//$obj->showme2();
//$obj->showme();


/*
echo '<br/> st'.DemoController::$state;
echo '<br/> pu'.$obj->pub;
echo '<br/> con'.DemoController::STATE;*/


