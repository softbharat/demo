@extends('layout.default')

@section('content')

    <div class="row">
        <div class="col-lg-12 margin-tb">
            <div class="pull-left">
                <h2> Show Profile</h2>
            </div>
            <div class="pull-right">
                <a class="btn btn-primary" href="{{ route('userprofile.index') }}"> Back</a>
            </div>
        </div>
    </div>

    <div class="row">

        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>User Name:</strong>
                {{ $user->user_name }}
            </div>
        </div>

        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>User Email:</strong>
                {{ $user->user_email }}
            </div>
        </div>


        <div class="col-xs-12 col-sm-12 col-md-12">
            <div class="form-group">
                <strong>User Mobile:</strong>
                {{ $user->user_mobile }}
            </div>
        </div>

    </div>

@endsection