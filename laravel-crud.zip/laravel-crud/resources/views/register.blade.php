<html class="">
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.5/css/bootstrap.min.css" rel="stylesheet" type="text/css">
    <link href="//cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.2.0/css/datepicker.min.css" rel="stylesheet" type="text/css">
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/2.0.3/jquery.min.js" type="text/javascript"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/3.0.0/js/bootstrap.min.js" type="text/javascript"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.2.0/js/bootstrap-datepicker.min.js" type="text/javascript"></script>

</head>
<body>
<div class="container">
    <div class="panel panel-primary dialog-panel">
        <div class="panel-heading">
            <h5>Registration</h5>
        </div>
        <div class="panel-body">
            <form class="form-horizontal" role="form">

                <div class="form-group">
                    <label class="control-label col-md-2 col-md-offset-2" for="id_name">Name</label>
                        <div class="col-md-3 indent-small">
                            <div class="form-group internal">
                                <input class="form-control" id="id_name" placeholder="Full Name" type="text">
                            </div>
                        </div>

                    </div>

                <div class="form-group">
                    <label class="control-label col-md-2 col-md-offset-2" for="id_country">Country</label>
                    <div class="col-md-2">
                        <select class="form-control" id="id_country">
                            <option value="India">India</option>
                            <option value="USA">USA</option>
                            <option value="UK">UK</option>
                        </select>
                    </div>
                </div>

                <div class="form-group">
                    <label class="control-label col-md-2 col-md-offset-2" for="id_email">Contact</label>
                    <div class="col-md-6">
                        <div class="form-group">
                            <div class="col-md-11">
                                <input class="form-control" id="id_email" placeholder="E-mail" type="text">
                            </div>
                        </div>
                        <div class="form-group internal">
                            <div class="col-md-11">
                                <input class="form-control" id="id_phone" placeholder="Phone" type="text">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-md-2 col-md-offset-2" for="id_reg">Register Date</label>
                    <div class="col-md-8">
                        <div class="col-md-3">
                            <div class="form-group internal input-group">
                                <input class="form-control datepicker" id="id_reg">
                                <span class="input-group-addon">
                    <i class="glyphicon glyphicon-calendar"></i>
                  </span>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-md-2 col-md-offset-2" for="id_equipment">Equipment type</label>
                    <div class="col-md-8">
                        <div class="col-md-3">
                            <div class="form-group internal">
                                <select class="form-control" id="id_equipment">
                                    <option>Travel trailer</option>
                                    <option>Fifth wheel</option>
                                    <option>RV/Motorhome</option>
                                    <option>Tent trailer</option>
                                    <option>Pickup camper</option>
                                    <option>Camper van</option>
                                </select>
                            </div>
                        </div>

                    </div>
                </div>
                <div class="form-group">
                    <label class="control-label col-md-2 col-md-offset-2" for="id_service">Required Service</label>
                    <div class="col-md-8">
                        <select class="multiselect" id="id_service" multiple="multiple">
                            <option value="hydro">Hydro</option>
                            <option value="water">Water</option>
                            <option value="sewer">Sewer</option>
                        </select>
                    </div>
                </div>

                <div class="form-group">
                    <label class="control-label col-md-2 col-md-offset-2" for="id_comments">Comments</label>
                    <div class="col-md-6">
                        <textarea class="form-control" id="id_comments" placeholder="Additional comments" rows="3"></textarea>
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-md-offset-4 col-md-3">
                        <button class="btn-lg btn-primary" type="submit">Request Reservation</button>
                    </div>
                    <div class="col-md-3">
                        <button class="btn-lg btn-danger" style="float:right" type="submit">Cancel</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>


<script>$(document).ready(function() {

        $('.datepicker').datepicker();
    });


    //# sourceURL=pen.js
</script>
</body></html>