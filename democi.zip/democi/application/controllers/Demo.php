<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Demo extends CI_Controller {

Public function __construct()
{
	parent::__construct();
	$this->load->helper('url');

}
	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
	
	echo 'IT IS INDEX PAGE';
		//$this->load->view('welcome_message');
		
		/*
		$data = array(
'roll_no' => 3,
'name' => "SIMRAN"
);
$this->db->insert("stud", $data);
		*/
		
		$data = array(
'name' => 'HAHAHAH'
);
$this->db->set($data);
$this->db->where("roll_no", 2);
$this->db->update("stud", $data);

$this->db->delete("stud", "roll_no = 3");

$query = $this->db->get("stud");
print_r($query->result());



$query = $this->db->get_where("stud",array('roll_no'=>1));
print_r($query->result());
		
	}
	
	public function store()
	{
	
	echo 'IT IS store PAGE';
		//$this->load->view('welcome_message');
	}
	
	
	public function update($product_id = NULL )
	{
	
	echo 'IT IS update PAGE'.$product_id;
	
	
		//$this->load->view('welcome_message');
	}
	
	public function update1($product_id = NULL )
	{
	
	echo 'IT IS update PAGE'.$product_id;
	
	
		//$this->load->view('welcome_message');
	}
	
	public function vlist($id, $version)
	{

	echo '<br/>'. $this->uri->segment(1);
	echo '<br/>'.$this->uri->segment(2);
	echo '<br/>'.$this->uri->segment(3);
	echo '<br/>'. $this->uri->segment(4);
	echo '<br/>'.$this->uri->segment(5);
	echo '<br/>'.$this->uri->segment(6);	
	echo 'IT IS list PAGE'.$id .', -version'.$version;
	
	
		//$this->load->view('welcome_message');
	}
	
	public function getlist($name)
	{
	echo '<br/>'. $this->uri->segment(1);
	echo '<br/>'.$this->uri->segment(2);
	echo '<br/>'.$this->uri->segment(3);
	
	echo 'IT IS list NMAE PAGE'.$name ;
	
	
		//$this->load->view('welcome_message');
	}
	
	
	
}
