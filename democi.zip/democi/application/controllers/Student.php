<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Student extends CI_Controller {

	Public function __construct()
	{
		parent::__construct();
		$this->load->helper('url');
		$this->load->model('student_model');
        $this->load->helper('url_helper');
		//$this->session->keep_flashdata('msg');
	}
	
	 public function index()
    {
        $data['users'] = $this->student_model->get_users();
        
        $this->load->view('templates/header');
        $this->load->view('student_view', $data);
        $this->load->view('templates/footer');
		
    }
 
 public function view($slug = NULL)
    {
        $data['users'] = $this->student_model->get_users($slug);
        
        if (empty($data['users']))
        {
            show_404();
        }
 
      
        $this->load->view('templates/header');
        $this->load->view('view', $data);
        $this->load->view('templates/footer');
    }
    
	
	public function create()
    {
        $this->load->library('form_validation');
		$this->form_validation->set_rules('email', 'Email', 'required');
        $this->form_validation->set_rules('name', 'Name', 'required|min_length[3]');
		$this->form_validation->set_rules('mobile', 'mobile', 'required|max_length[10]|callback_valid_number');
		$data['error'] = '';
        if ($this->form_validation->run() === FALSE)
        {
            $this->load->view('templates/header');
            $this->load->view('student_add',$data);
            $this->load->view('templates/footer');
 
        }
        else
        {
			
			$photo = $this->input->post('photo');
			$name = $this->input->post('name');
			$data['users'] = $this->student_model->get_users($name);
		if (!empty($data['users']))
        {
            $data['error']= 'User Already Exist!';
			$this->load->view('templates/header');
            $this->load->view('student_add',$data);
            $this->load->view('templates/footer');
			return;
			
        }	
			
			if($photo != ''){
			
			$config['upload_path'] = './images/user/';
			$config['allowed_types'] = 'gif|jpg|png';
			$new_name = time().$_FILES["photo"]['name'];
			$config['file_name'] = $new_name;
			$this->load->library('upload', $config);

			if ( ! $this->upload->do_upload('photo'))
			{
			$data['error']= $this->upload->display_errors();
			$this->load->view('templates/header');
            $this->load->view('student_add',$data);
            $this->load->view('templates/footer');
			}   
			else
			{
			//$this->do_resize($new_name);
			$this->student_model->set_users();
			$data['users'] = $this->student_model->get_users();
			$this->session->set_flashdata('msg','Created Successfully!');
			$this->load->view('templates/header');
            $this->load->view('student_view', $data);
            $this->load->view('templates/footer');

			}
			} else {
			
					//$this->do_resize($new_name);
			$this->student_model->set_users();
			$data['users'] = $this->student_model->get_users();
			$this->session->set_flashdata('msg','Created Successfully!');
			$this->load->view('templates/header');
            $this->load->view('student_view', $data);
            $this->load->view('templates/footer');

			}
			
			

			        }
    }
    
	
	
	public function edit()
    {
        $id = $this->uri->segment(3);
        
        if (empty($id))
        {
            show_404();
        }
        
         
		 $this->load->library('form_validation');
        
        $data['user_list'] = $this->student_model->get_user_by_id($id);
        
    	$this->form_validation->set_rules('email', 'Email', 'required');
        $this->form_validation->set_rules('name', 'Name', 'required');
		$this->form_validation->set_rules('mobile', 'mobile', 'required');
 
        if ($this->form_validation->run() === FALSE)
        {
            $this->load->view('templates/header');
            $this->load->view('student_edit', $data);
            $this->load->view('templates/footer');
 
        }
        else
        {
		$this->session->set_flashdata('msg','Updated Successfully!');
            $this->student_model->set_users($id);
            redirect( base_url() . 'student','refresh');
        }
    }
	
	public function delete()
    {
        $id = $this->uri->segment(3);
        
        if (empty($id))
        {
            show_404();
        }
                
        $user = $this->student_model->get_user_by_id($id);
        if(!empty($user)){
        $this->student_model->delete_user($id); 
		$this->session->set_flashdata('msg','Deleted Successfully!');		
        }
		redirect( base_url() . 'student','refresh');        
    }

	function valid_number($mobile){
	$this->form_validation->set_message('valid_number', 'The mobile must be valid digit');


	 if (preg_match('/\d/', $mobile)){
	 return true;
	 }else {
	 return false;
	 }
	
	}
	
	public function do_resize($new_name)
{
    $filename = $new_name;
    $source_path = $_SERVER['DOCUMENT_ROOT'] . '/images/user/' . $filename;
    $target_path = $_SERVER['DOCUMENT_ROOT'] . '/images/user/thumb/';
    $config_manip = array(
        'image_library' => 'gd2',
        'source_image' => $source_path,
        'new_image' => $target_path,
        'maintain_ratio' => TRUE,
        'create_thumb' => TRUE,
        'thumb_marker' => '_thumb',
        'width' => 150,
        'height' => 150
    );
    $this->load->library('image_lib', $config_manip);
    if (!$this->image_lib->resize()) {
        echo $this->image_lib->display_errors();
    }
    // clear //
    $this->image_lib->clear();
}
	
}
