  <h2>User </h2>
  <p>List In tabular form:</p>            
  <table class="table">
    <thead>
      <tr>
        <th>Name</th>
        <th>Mobile</th>
        <th>Email</th>
      </tr>
    </thead>
    <tbody>
        <tr>
            <td><?php echo $users['name']; ?></td>
            <td><?php echo $users['mobile']; ?></td>
            <td><?php echo $users['email']; ?></td>
            
			        </tr>
    </tbody>
  </table>
