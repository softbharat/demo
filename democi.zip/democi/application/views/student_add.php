  <h2>Student ADD</h2>
  <p class="text-warning">
  <?php //echo validation_errors(); ?>
  
  <?php echo $error;?>
 </p>
  <form action="<?php echo site_url('users/add_form'); ?>" method="post" enctype= "multipart/form-data">
    <div class="form-group">
      <label for="email">Email:</label>
      <input type="email" class="form-control" id="email" placeholder="Enter email" name="email" value="<?php echo set_value('email');?>">
	  <?php echo form_error('email','<div class="alert alert-danger">','</div'); ?>
  
    </div>
	
	<div class="form-group">
      <label for="name">Name:</label>
      <input type="text" class="form-control" id="name" placeholder="Enter Name" name="name" value="<?php echo set_value('name');?>">
	  <?php echo form_error('name','<div class="alert alert-danger">','</div'); ?>
    </div>
	
	<div class="form-group">
      <label for="mobile">Mobile:</label>
      <input type="text" class="form-control" id="mobile" placeholder="Enter Name" name="mobile" value="<?php echo set_value('mobile');?>">
	  <?php echo form_error('mobile','<div class="alert alert-danger">','</div'); ?>
    </div>
	
	
	<div class="form-group">
      <label for="photo">Photo:</label>
      <input type="file" class="form-control" id="photo" placeholder="Enter Name" name="photo">
    </div>
	
	
    <button type="submit" class="btn btn-default">Submit</button>
	
	<a href="<?php echo site_url('users'); ?>" class="btn btn-default">Cancel</a>
  </form>
