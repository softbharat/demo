  <h2>Student Edit</h2>
  <p class="text-warning">
  <?php echo validation_errors(); ?>
 </p>
  <form action="<?php echo site_url('users/edit/'.$user_list['id']); ?>" method="post">
    <div class="form-group">
      <label for="email">Email:</label>
      <input type="email" class="form-control" id="email" placeholder="Enter email" name="email" value="<?php echo $user_list['email']; ?>">
    </div>
	
	<div class="form-group">
      <label for="name">Name:</label>
      <input type="text" class="form-control" id="name" placeholder="Enter Name" name="name" value="<?php echo $user_list['name']; ?>">
    </div>
	
	<div class="form-group">
      <label for="mobile">Mobile:</label>
      <input type="text" class="form-control" id="mobile" placeholder="Enter Name" name="mobile" value="<?php echo $user_list['mobile']; ?>">
    </div>
	
	
	<div class="form-group">
      <label for="photo">Photo:</label>
      <input type="file" class="form-control" id="photo" placeholder="Enter Name" name="photo">
    </div>
	
	
    <button type="submit" class="btn btn-default">Edit</button>
	
	<a href="<?php echo site_url('users'); ?>" class="btn btn-default">Cancel</a>
  </form>
