  <h2>User List
  
  <a href="<?php echo site_url('users/add_form'); ?>">Add</a>
  
  </h2>
  <p>List In tabular form:</p>     
<div class="alert">
<?php 
if($this->session->flashdata('msg')){
echo $this->session->flashdata('msg');
}
?>  
</div>
  <table class="table">
    <thead>
      <tr>
        <th>Name</th>
        <th>Mobile</th>
        <th>Email</th>
		<th>Action</th>
      </tr>
    </thead>
    <tbody>
      <?php foreach ($users as $user): ?>
        <tr>
            <td><?php echo $user['name']; ?></td>
            <td><?php echo $user['mobile']; ?></td>
            <td><?php echo $user['email']; ?></td>
            
			<td>
                <a href="<?php echo site_url('user/'.$user['name']); ?>">View</a> | 
                <a href="<?php echo site_url('users/edit/'.$user['id']); ?>">Edit</a> | 
                <a href="<?php echo site_url('users/delete/'.$user['id']); ?>" onClick="return confirm('Are you sure you want to delete?')">Delete</a>
            </td>
        </tr>
<?php endforeach; ?>
    </tbody>
  </table>
