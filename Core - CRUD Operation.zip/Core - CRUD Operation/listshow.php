<?php
include_once('includes/dbconfig.php');
include_once('templates/header.php');
$user_id = $_GET['user_id'];
if(empty($user_id) || !is_numeric($user_id)){
    echo 'user is invalid';exit;
}


$query = "SELECT * FROM flt_users WHERE user_id=".$user_id;
$result = mysqli_query($con, $query);
$row = mysqli_fetch_assoc($result);
extract($row);

?>
<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2> Show Profile</h2>
        </div>
        <div class="pull-right">
            <a class="btn btn-primary" href="list.php"> Back</a>
        </div>
    </div>
</div>

<div class="row">

    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>User Name:</strong>
	        <?php echo $user_name; ?>
        </div>
    </div>

    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>User Email:</strong>
	        <?php echo $user_email; ?>
        </div>
    </div>


    <div class="col-xs-12 col-sm-12 col-md-12">
        <div class="form-group">
            <strong>User Mobile:</strong>
	        <?php echo $user_mobile; ?>
        </div>
    </div>

</div>


<?php
include_once('templates/footer.php');
?>

