<?php
include_once('includes/dbconfig.php');
include_once('templates/header.php');

if($_GET['action']=='delete' && !empty($_GET['delet_id'])){
    $delet_id =$_GET['delet_id'];
    $sql = "DELETE FROM flt_users WHERE user_id=".$delet_id;
	if (!mysqli_query($con,$sql))
	{
		die('Error: ' . mysqli_error($con));
	}
	header('location:list.php?msg=Delete successfully!');
	exit;
    
}
$per_page=25;
if (isset($_GET["page"])) {
	$page = $_GET["page"];
}
else {
	$page=1;
}

// Page will start from 0 and Multiple by Per Page
$start_from = ($page-1) * $per_page;

//Selecting the data from table but with limit
$query = " SELECT * FROM flt_users ORDER BY user_id DESC LIMIT $start_from, $per_page";
$result = mysqli_query($con, $query);

?>
<div class="row">
	<div class="col-lg-12 margin-tb">
		<div class="pull-left">
			<h2>CRUD Operation</h2>
		</div>
		<div class="pull-right">
			<a class="btn btn-success" href="listadd.php"> Add New User</a>
		</div>
	</div>
</div>

<?php
    if(!empty($_GET['msg'])){
 ?>
<div class="alert alert-success">
	<p>
        <?php echo $_GET['msg'];?>
    </p>
</div>
<?php
    }
?>

<table class="table table-bordered">
	<tr>
		<th>No</th>
		<th>Name</th>
		<th>Email</th>
		<th>Mobile</th>
		<th >Action</th>
	</tr>
	<?php
    
	while ($row = mysqli_fetch_assoc($result)) {
		
	?>
	
	<tr>
		<td><?php echo  ++$i ?></td>
		<td> <?php echo $row['user_name'] ?></td>
		<td><?php echo $row['user_email'] ?></td>
		<td><?php echo $row['user_mobile'] ?></td>
		<td>
			<a class="btn btn-info" href="listshow.php?user_id=<?php echo $row['user_id']; ?>">Show</a>
			<a class="btn btn-primary" href="listedit.php?user_id=<?php echo $row['user_id']; ?>">Edit</a>
			<form style="display: inline-table;" action="list.php?delet_id=<?php echo $row['user_id']; ?>&action=delete" method="post">
				<button type="submit" class="btn btn-danger">Delete</button>
			</form>
		</td>
	</tr>
	<?php }
	?>
</table>

<div>
    <ul class="pagination">
<?php
	
//Now select all from table
$query = "select * from flt_users";
$result = mysqli_query($con, $query);

// Count the total records
$total_records = mysqli_num_rows($result);

//Using ceil function to divide the total records on per page
$total_pages = ceil($total_records / $per_page);

//Going to first page
echo "<li><a href='list.php?page=1'>"."First Page"."</a> </li>";

for ($i=1; $i<=$total_pages; $i++) {
	
	echo "<li><a href='list.php?page=$i'>".$i."</a> </li>";
};
// Going to last page
echo "<li><a href='list.php?page=$total_pages'>"."Last Page"."</a></li>";
?>
    </ul>
</div>

<?php
include_once('templates/footer.php');
?>

