<?php
include_once('includes/dbconfig.php');
include_once('templates/header.php');

if(isset($_POST['submit_form'])){
    extract($_POST);
	
	$error_exist = false;
	$errors =[];
	if(empty($user_name)){
		$error_exist = true;
		$errors[] ='Please enter your name';
    }elseif (strlen($user_name) <10 ){
		$errors[] ='your name must be atleast 10 char';
		$error_exist = true;
    }
	if(empty($user_email)){
		$error_exist = true;
		$errors[] ='Please enter your name';
	}elseif (!(filter_var($user_email, FILTER_VALIDATE_EMAIL)) ){
		$errors[] ='email is not valid';
		$error_exist = true;
	}
	
	if(empty($user_mobile)){
		$errors[] ='Please enter your mobile';
		$error_exist = true;
	}elseif (!preg_match("/^\d{10}?$/", $user_mobile) ){
		$errors[] ='mobile is not valid';
		$error_exist = true;
	}
	
	if(empty($user_country)){
		$errors[] ='Please select country';
		$error_exist = true;
	}
	if(empty($user_date)){
		$errors[] ='Please select date';
		$error_exist = true;
	}
	
	
	if(!$error_exist) {
		$time =time();
		$sql= " INSERT INTO flt_users "
            . " (user_name, user_email, user_mobile,user_login, user_password, user_firstname,user_lastname, user_acc_type, user_gender, user_country, user_updated)"
			. " VALUES ('$user_name','$user_email','$user_mobile','$user_email','$user_mobile','$user_name','$user_name','1','$user_gender','$user_country','$time')";
		
		if (!mysqli_query($con,$sql))
		{
			die('Error: ' . mysqli_error($con));
		}
		header('location:list.php?msg=addedd successfully!');
		exit;
    }
	
}else{
    $user_country = $user_date =$user_email=$user_mobile=$user_name=$user_gender='';
}

?>
<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2>Add New User</h2>
        </div>
        <div class="pull-right">
            <a class="btn btn-primary" href="list.php"> Back</a>
        </div>
    </div>
</div>

<?php
if(!empty($errors)) {
	?>

    <div class="alert alert-danger">
        There were some problems with your input.<br><br>
        <ul>
	        <?php
            foreach ($errors as $error){
	            echo '<li>'. $error .'</li>';
            }
            ?>
            
        </ul>
    </div>
	<?php
}
?>
<form  name="create" action="" id="create" method="post">
   

    <div class="row">
        <div class="col-lg-6">
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>User Name:</strong>
                        <input type="text" name="user_name" id="user_name" placeholder="User Name" class="form-control" value="<?php echo $user_name; ?>">

                    </div>
                </div>

                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>Email:</strong>
                        <input type="text" name="user_email" id="user_email" placeholder="User Email" class="form-control" value="<?php echo $user_email; ?>">
                    </div>
                </div>

                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>Mobile:</strong>
                        <input type="text" name="user_mobile" id="user_mobile" placeholder="User Mobile" class="form-control"  value="<?php echo $user_mobile; ?>">

                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>Country:</strong>
                        <?php
                       
                        $select_india = '';
                        $select_usa = '';
                        $select_uk = '';
                        
                        if($user_country == 'India')
                        $select_india = 'selected="selected"';
                       
                        elseif($user_country == 'USA')
                        $select_usa = 'selected="selected"';
                        
                        elseif($user_country == 'UK')
                        $select_uk = 'selected="selected"';
                       
                        
                        ?>
                        <select class="form-control" id="user_country" name="user_country">
                            <option value="">Select</option>
                            <option value="India" <?php echo $select_india; ?>>India</option>
                            <option value="USA" <?php echo $select_usa ?>>USA</option>
                            <option value="UK" <?php echo $select_uk ?>>UK</option>
                        </select>

                    </div>
                </div>


                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
                        <strong>Register Date:</strong>

                        <input class="form-control datepicker" id="id_reg" name="user_date" value="<?php echo $user_date; ?>">



                    </div>
                </div>
                <div class="col-xs-12 col-sm-12 col-md-12">
                    <div class="form-group">
	                    <?php
                        $select_male = '';
                        $select_female = '';

                        if($user_gender == 'Male')
                        $select_male = 'checked="checked"';
                        
                        elseif($user_gender == 'Female')
                        $select_female = 'checked="checked"';
                        ?>
                        <strong>Gender:</strong>
                        <div class="form-control" style="border: 0px;">

                            <input type="radio" name="user_gender" id="user_gender" value="Male" <?php echo $select_male ?>> Male

                            &nbsp;&nbsp;
                            <input type="radio" name="user_gender" id="user_gender" value="Female" <?php echo $select_female ?> > FeMale
                        </div>
                    </div>
                </div>



                <div class="col-xs-12 col-sm-12 col-md-12 text-center">
                    <button type="submit" class="btn btn-primary" id="submit_form" name="submit_form">Submit</button>
                </div>

            </div>
        </div>
    </div>
</form>

<script>
    $(document).ready(function() {
        $('.datepicker').datepicker();

        $.validator.addMethod("valid_date", function(value, element) {
            var flag = false;
            var date = value;
            arr_date = date.split('/');
            var day =arr_date[1];
            var mon =arr_date[0];
            var year =arr_date[2];

            if(day<1 || day >31){
                return false;
            }
            if(mon<1 || mon >12){
                return false;
            }
            if(year<2010){
                return false;
            }
            return true;
        }, "");
        // validate signup form on keyup and submit
        $("#create").validate({
            rules: {
                user_name: {
                    required: true,
                    minlength: 2
                },
                user_country: {
                    required: true

                },
                user_date: {
                    required: true,
                    valid_date : true
                },
                user_email: {
                    required: true,
                    email: true
                },
                user_mobile: {
                    required: true,
                    minlength: 10,
                    number:true
                },

            },
            messages: {

                user_mobile: "Please enter mobile",
                user_email: {
                    required: "Please enter email",
                    email: "Enter valid email"
                },
                user_name: {
                    required: "Please enter your name",
                    minlength: "Your name must be at least 2 characters long"
                },
                user_country: "Please select country",
                user_date:{
                    required:"Please select date",
                    valid_date :'Please select valid date'
                }

            },
            errorPlacement:function(error, element) {
                error.insertAfter(element);
            },

            submitHandler: function(form) {

                form.submit();
            }

        });
    });
</script>

<?php
include_once('templates/footer.php');
?>

