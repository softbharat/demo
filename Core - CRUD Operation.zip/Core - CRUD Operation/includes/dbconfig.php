<?php
$con =mysqli_connect('192.168.1.10','flntrd','flinnt','flinnt_v3');
if($con->connect_error){
	die('Not connected');
}