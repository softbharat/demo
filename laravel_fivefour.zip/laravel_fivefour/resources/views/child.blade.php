@extends('layouts.app')
@section('title','Blade Example')

@section('sidebar')
 @parent
<p>New side content </p>

@endsection




@section('content')

<div class="row">
{{-- This comment will not be present in the rendered HTML --}}
 <h1> Bharat Create Child Page {{ $name}}</h1>
</div>


@endsection

<script type="text/javascript">
var USER_NAME = '{{ $name}}';
//Jquery("h1").css('color','red');
console.log(USER_NAME);
</script>

mix.js('resources/assets/js/app.js', 'public/js')
   .sass('resources/assets/sass/app.scss', 'public/css');