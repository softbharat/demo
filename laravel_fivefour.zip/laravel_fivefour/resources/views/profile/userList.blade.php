@extends('layouts.master')

@section('content')

<h2>Larevel Record List
		<a class='btn btn-success pull-right' href="{{ route('profile.create')}}">Add</a>
</h2>

  <p>Note : List Display Dynamic Data.</p>

  <p class='pull-right'>
  <a href="{{ url('profile/excel')}}" class="btn btn-info" > Export Excel</a> 
  <a href="{{ url('profile/pdf')}}" class="btn btn-info" > Export PDF</a> 
  </p>

  
  @if(session('msg'))
		<p class='alert alert-success'>{{ session('msg')}} <p>
  @endif


 
  <table class="table table-bordered">
    <thead>
      <tr>
        <th>User Name</th>
        <th>Email</th>
        <th>Mobile</th>
		<th>Profile Photo</th>
		<th>Action</th>
      </tr>
    </thead>
    <tbody>
	
	@foreach($users as $user)
      <tr>
        <td>{{ $user->user_name }}</td>
        <td>{{ $user->user_email }}</td>
        <td>{{ $user->user_mobile }}</td>
	
	
		
		@if($user->user_photo !='')
		<td><img src="{{ asset('uploads/'.$user->user_photo)}}" width="50"/></td>
		@else
		<td>-</td>
		@endif
		<td> 
		<a class='btn btn-info' href="{{ route('profile.edit',['id'=>$user->user_id ])}}">Edit</a>
		
		<form action="{{ route('profile.destroy',['id'=>$user->user_id])}}" method="post">
			<input type="hidden" name="_token" value="{{ csrf_token()}}">
			<input type="hidden" name="_method" value="DELETE">
 
		<button type="submit" class='btn btn-danger'>Delete</button>
		
	</form>	
		</td>
      </tr>
	@endforeach  
      
    </tbody>
  </table>
  
  {{ $users->links() }}
  
@endsection
