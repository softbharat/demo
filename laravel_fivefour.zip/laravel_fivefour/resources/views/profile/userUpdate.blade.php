@extends('layouts.master')

@section('content')

<h2>Update User
		<a class='btn btn-info pull-right' href="{{ route('profile.index')}}">Back</a>
</h2>
  <p>Note : All Fields are mandatory.</p>
  
  
  <div class='row'>
  <div class='col-md-6'>
  <form action="{{ route('profile.update',['id'=>$user->user_id])}}" method="post">
  
  
  @if(count($errors)>0)
   <div class="alert alert-danger">
   <ul>
    @foreach($errors->all() as $err)
	 <li> {{ $err }}</li>
	@endforeach
	</ul>
	</div>
  @endif
  
  
  <input type="hidden" name="_token" value="{{ csrf_token()}}">
  <input type="hidden" name="_method" value="PUT">
 
  
  <div class="form-group">
    <label for="user_name">User Name:</label>
	
	@if(old('user_name')!='')
	@php
		    $user->user_name = old('user_name')
	@endphp			
	@elseif($user->user_name !='')
	@php
	    $user->user_name = $user->user_name
	@endphp	
	@endif		
    <input type="text" class="form-control" id="user_name" name="user_name" value="{{ $user->user_name}}">
	<div class="alert alert-danger" style='display:none;' id='user_error'></div>
	
  </div>
  <div class="form-group">
    <label for="email">EMail:</label>
	@if(old('user_email')!='')
	@php
		    $user->user_email = old('user_email')
	@endphp		
	@elseif($user->user_email !='')
	@php
	    $user->user_email = $user->user_email
	@endphp	
	
	@endif
    <input type="text" class="form-control" id="user_email" name="user_email" value="{{ $user->user_email}}">
	<div class="alert alert-danger" style='display:none;' id='email_error'></div>
	
  </div>
  
  <div class="form-group">
    <label for="mobile">Mobile:</label>
	@if(old('user_mobile')!='')
	@php
		    $user->user_mobile = old('user_mobile')
	@endphp
	@elseif($user->user_mobile !='')
	@php
	    $user->user_mobile = $user->user_mobile
	@endphp

	@endif
    <input type="text" class="form-control" id="user_mobile" name="user_mobile" value="{{ $user->user_mobile}}">
	<div class="alert alert-danger" style='display:none;' id='mobile_error'></div>
	
  </div>
  
  
  
  <button type="submit" class="btn btn-default" id="submit">Update</button>
  <button type="reset" class="btn btn-default">Reset</button>
  
</form>
</div>
</div>
  
  <script type="text/javascript">
  /*
  $('document').ready(function(){
    $('#submit').click(function(){
	   var error_flag= false;
	   
	   user_name = $('#user_name').val();
	   user_email = $('#user_email').val();
	   user_mobile = $('#user_mobile').val();
	   $('#user_error').hide();
	   $('#email_error').hide();
	   $('#mobile_error').hide();
	   if($.trim(user_name)==''){
			error_flag = true;
			$('#user_error').show().html('Please enter name');
	   }
	   
	   if($.trim(user_email)==''){
			error_flag = true;
			$('#email_error').show().html('Please enter email');
	   }
	   if($.trim(user_mobile)==''){
			error_flag = true;
			$('#mobile_error').show().html('Please enter mobile');
	   }
	   
	   
	   if(error_flag){
	    return false;
	   } else {
	   return true;
	   }
	   
	});
  });
*/  
  </script>
  
  
@endsection
