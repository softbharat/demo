@extends('layouts.master')

@section('content')

<h2>Add New User
		<a class='btn btn-info pull-right' href="{{ route('profile.index')}}">Back</a>
</h2>
  <p>Note : All Fields are mandatory.</p>
  
  
  <div class='row'>
  <div class='col-md-6'>
  <form action="{{ route('profile.store')}}" method="post" enctype="multipart/form-data">
  
  
  @if(count($errors)>0)
   <div class="alert alert-danger">
   <ul>
    @foreach($errors->all() as $err)
	 <li> {{ $err }}</li>
	@endforeach
	</ul>
	</div>
  @endif
  
  
  <input type="hidden" name="_token" value="{{ csrf_token()}}">
  <div class="form-group">
    <label for="user_name">User Name:</label>
	
    <input type="text" class="form-control" id="user_name" name="user_name">
	<div class="alert alert-danger" style='display:none;' id='user_error'></div>
	
  </div>
  <div class="form-group">
    <label for="email">EMail:</label>
    <input type="text" class="form-control" id="user_email" name="user_email">
	<div class="alert alert-danger" style='display:none;' id='email_error'></div>
	
  </div>
  
  <div class="form-group">
    <label for="mobile">Mobile:</label>
    <input type="text" class="form-control" id="user_mobile" name="user_mobile">
	<div class="alert alert-danger" style='display:none;' id='mobile_error'></div>
	
  </div>
  
  
  <div class="form-group">
    <label for="mobile">Profile Photo:</label>
    <input type="file" class="form-control" id="user_photo" name="user_photo">
	
	
  </div>
  
  
  
  
  
  <button type="submit" class="btn btn-default" id="submit">Submit</button>
  <button type="reset" class="btn btn-default">Reset</button>
  
</form>
</div>
</div>
  
  <script type="text/javascript">
  /*
  $('document').ready(function(){
    $('#submit').click(function(){
	   var error_flag= false;
	   
	   user_name = $('#user_name').val();
	   user_email = $('#user_email').val();
	   user_mobile = $('#user_mobile').val();
	   $('#user_error').hide();
	   $('#email_error').hide();
	   $('#mobile_error').hide();
	   if($.trim(user_name)==''){
			error_flag = true;
			$('#user_error').show().html('Please enter name');
	   }
	   
	   if($.trim(user_email)==''){
			error_flag = true;
			$('#email_error').show().html('Please enter email');
	   }
	   if($.trim(user_mobile)==''){
			error_flag = true;
			$('#mobile_error').show().html('Please enter mobile');
	   }
	   
	   
	   if(error_flag){
	    return false;
	   } else {
	   return true;
	   }
	   
	});
  });
*/  
  </script>
  
  
@endsection
