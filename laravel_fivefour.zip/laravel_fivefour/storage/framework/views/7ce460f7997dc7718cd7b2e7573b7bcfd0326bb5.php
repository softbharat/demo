<?php $__env->startSection('content'); ?>

<h2>Larevel Record List
		<a class='btn btn-success pull-right' href='<?php echo e(route('profile.create')); ?>'>Add</a>
</h2>
  <p>Note : List Display Dynamic Data.</p>
  
  <table class="table table-bordered">
    <thead>
      <tr>
        <th>User Name</th>
        <th>Email</th>
        <th>Mobile</th>
		<th>Profile Photo</th>
		<th>Action</th>
      </tr>
    </thead>
    <tbody>
	
	<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e($user->user_name); ?></td>
        <td><?php echo e($user->user_email); ?></td>
        <td><?php echo e($user->user_mobile); ?></td>
		<td>-</td>
		
		<td> 
		<a class='btn btn-info' href='#'>Edit</a>
		<a class='btn btn-danger' href='#'>Delete</a>
		</td>
      </tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
      
    </tbody>
  </table>
  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>