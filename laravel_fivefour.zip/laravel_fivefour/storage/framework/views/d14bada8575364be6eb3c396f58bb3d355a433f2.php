<?php $__env->startSection('content'); ?>

<h2>Larevel Record List
		<a class='btn btn-success pull-right' href="<?php echo e(route('profile.create')); ?>">Add</a>
</h2>

  <p>Note : List Display Dynamic Data.</p>

  <p class='pull-right'>
  <a href="<?php echo e(url('profile/excel')); ?>" class="btn btn-info" > Export Excel</a> 
  <a href="<?php echo e(url('profile/pdf')); ?>" class="btn btn-info" > Export PDF</a> 
  </p>

  
  <?php if(session('msg')): ?>
		<p class='alert alert-success'><?php echo e(session('msg')); ?> <p>
  <?php endif; ?>


 
  <table class="table table-bordered">
    <thead>
      <tr>
        <th>User Name</th>
        <th>Email</th>
        <th>Mobile</th>
		<th>Profile Photo</th>
		<th>Action</th>
      </tr>
    </thead>
    <tbody>
	
	<?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e($user->user_name); ?></td>
        <td><?php echo e($user->user_email); ?></td>
        <td><?php echo e($user->user_mobile); ?></td>
	
	
		
		<?php if($user->user_photo !=''): ?>
		<td><img src="<?php echo e(asset('uploads/'.$user->user_photo)); ?>" width="50"/></td>
		<?php else: ?>
		<td>-</td>
		<?php endif; ?>
		<td> 
		<a class='btn btn-info' href="<?php echo e(route('profile.edit',['id'=>$user->user_id ])); ?>">Edit</a>
		
		<form action="<?php echo e(route('profile.destroy',['id'=>$user->user_id])); ?>" method="post">
			<input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
			<input type="hidden" name="_method" value="DELETE">
 
		<button type="submit" class='btn btn-danger'>Delete</button>
		
	</form>	
		</td>
      </tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
      
    </tbody>
  </table>
  
  <?php echo e($users->links()); ?>

  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>