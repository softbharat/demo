<?php $__env->startSection('title','Blade Example'); ?>

<?php $__env->startSection('sidebar'); ?>
 ##parent-placeholder-19bd1503d9bad449304cc6b4e977b74bac6cc771##
<p>New side content </p>

<?php $__env->stopSection(); ?>




<?php $__env->startSection('content'); ?>

<div class="row">

 <h1> Bharat Create Child Page <?php echo e($name); ?></h1>
</div>


<?php $__env->stopSection(); ?>

<script type="text/javascript">
var USER_NAME = '<?php echo e($name); ?>';
//Jquery("h1").css('color','red');
console.log(USER_NAME);
</script>

mix.js('resources/assets/js/app.js', 'public/js')
   .sass('resources/assets/sass/app.scss', 'public/css');
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>