<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use \App\Profile;
//use Intervention\Image\Facades\Image;
use Excel;
use PDF;
class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
	
		$users = Profile::paginate('5');
        return view('profile.userList',['users'=>$users]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
	    //echo 'come here';exit;
        return view('profile.userRegister');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request,
		[
		'user_name'=>'required',
		'user_email'=>'required|email',
		'user_mobile'=>'required|digits:10'
		]
		);
		$image_name ='';
		if ($request->hasFile('user_photo'))
		{
		
		$file = $request->user_photo;
        $image_name = time()."-".$file->getClientOriginalName();
        $file->move('uploads', $image_name);
		//$image = Image::make(sprintf('uploads/%s', $image_name))->resize(200, 200)->save();
		}
		
		
		
		$user = new Profile();
		$user->user_name = $request->user_name;
		$user->user_email = $request->user_email;
		$user->user_mobile = $request->user_mobile;
		$user->user_photo = $image_name;
		$user->save();
		return redirect()->route('profile.index')->with('msg','Addedd Successfully!');
		
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
       $user =  Profile::findorfail($id);
	    if(empty($user->user_id)){
		//abort('404');
		}
		return view('profile.userUpdate',['user'=>$user]);
       
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
	$this->validate($request,
		[
		'user_name'=>'required',
		'user_email'=>'required|email',
		'user_mobile'=>'required|digits:10'
		]
		);
		
        $user =Profile::find($id);
		$user->user_name = $request->user_name;
		$user->user_email = $request->user_email;
		$user->user_mobile = $request->user_mobile;
		$user->save();
		return redirect()->route('profile.index')->with('msg','Update Successfully!');
		

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
     Profile::destroy($id);   
	 return redirect()->route('profile.index')->with('msg','Deleted Successfully!');
	}
	
	public function exportexcel(){
	//https://github.com/Maatwebsite/Laravel-Excel
	//http://www.maatwebsite.nl/laravel-excel/docs/export
	//http://www.maatwebsite.nl/laravel-excel/docs/getting-started#installation
	
	/*
		$data = array(
			array('data1', 'data2'),
			array('data3', 'data4')
		);
	*/	
		$data = Profile::all();
		
		Excel::create('userlist', function($excel) use($data) {

			$excel->sheet('Sheetname', function($sheet) use($data) {

				$sheet->fromArray($data);

			},'','A1');

		})
		//->store('xls', public_path('excel'));
		->export('xls');
		// return redirect()->route('profile.index')->with('msg','File Generate Successfully!');
	}
	
	public function exportpdf(){
	//https://github.com/barryvdh/laravel-snappy
	//https://github.com/KnpLabs/snappy#wkhtmltopdf-binary-as-composer-dependencies
	$users = Profile::paginate('5');
        //return view('profile.userList',['users'=>$users]);
			$pdf = PDF::loadView('profile.userList', ['users'=>$users]);
			return $pdf->download('invoice.pdf');
	}
	
	
	public function adminpanel(){
	//http://laraveldaily.com/packages/quickadmin/
	//https://laravel-backpack.readme.io/docs/install-on-laravel-54
	
	}
	
}
