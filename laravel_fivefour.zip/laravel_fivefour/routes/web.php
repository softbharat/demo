<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});


/**************************** USER ROUTE INSERT/UPDATE/DELETE/LIST*********************************************************************/
//http://127.0.0.1:8000/profile
Route::get('profile/pdf', 'UserController@exportpdf');
Route::get('profile/excel', 'UserController@exportexcel');
Route::resource('profile','UserController');



















/* ALL BELOW FOR DEMO */
/*
Route::get('foo',function(){
return 'Hello WOrld';
});

Route::any('fooany',function(){
return 'Any Hello WOrld Route';
});

Route::get('user/{id}',function ($Id){
//echo 'The User Id'.$Id;
return redirect()->route('profile');
});


Route::get('post/{post}/comment/{comment}',function ($postId,$commentId){
echo 'The User Post Id'.$postId .'  ANd COmment Id'.$commentId;
});

Route::get('post-all/{post_id}/comment-all/{comment_id}',function ($postId,$commentId){
echo 'The User Post Id'.$postId .'  ANd COmment Id'.$commentId;
});


Route::get('users/{name?}',function ($name='Roy sinha'){
echo 'The User Name'.$name;
})->where('name','[A-Za-z]+');



Route::get('profile/{userid}/{username}',function ($id,$name){
echo 'The profile Name'.$name .' ANd ID'.$id;
})->where(['username'=>'[A-Za-z]+','userid'=>'[0-9]+']);


Route::get('userq/profile',function (){
echo 'route name apply'; 
})->name('profile');




Route::group(['middleware' => 'auth'], function () {
    Route::get('bharat', function ()    {
        return 'Uses Auth Middleware';
    });

    Route::get('userlogin/profile', function () {
        return' Uses Auth Middleware';
    });
});



Route::group(['prefix' => 'admin'], function () {
    Route::get('dashboard', function ()    {
        return 'User Admin Dashboard';
    });

    Route::get('product', function () {
        return' admin product';
    });
});
//http://127.0.0.1:8000/test?color=red
//http://127.0.0.1:8000/test?color=red&test=87&name=rew
use Illuminate\Support\Facades\Input;
Route::get('test',function(){
	echo 'param '.Input::get('color');
	print_r(Input::all());
});

Route::get('bladeview',function(){
	return view('child',['name'=>'IT A JUMPING']);
});


*/

/* END ALL BELOW FOR DEMO */